# COMP4300_Mega_bites

Project Group Members:

* YeongShu Chun (201623048, yschun@mun.ca)
* Mahmoud Elramlawy (201727021, mselramlawy@mun.ca)
* Hussein Abdelrahman (201762846, habdelrahman@mun.ca)
* Nehar Uzzal Biswas Bashu 4 (201716099, nubbashu@mun.ca)

Project Videos:

* Project Demo: https://youtu.be/xEge4S4Sp9k
* Project Trailer: https://youtu.be/9oHx1RJa_GM
* Project Presentation: https://youtu.be/C-iZnBqUoNU

Project Setup / Installation:

* Run SFMLGame.exe in the bin folder


Asset Sources:
* https://www.freepik.com/premium-vector/lava-pixel-art-texture-magma-tile-seamless-pattern-8-bit-sprite_28762550.htm
* https://aztrakatze.itch.io/simple-cute-robot
* https://free-game-assets.itch.io/free-industrial-zone-tileset-pixel-art
* https://www.pngegg.com/en/png-noduu
* https://camacebra.itch.io/kingslime?download
* Enter the gungeon
* Megaman
* Metroid II
* https://i.pinimg.com/originals/f3/5f/5b/f35f5b3c2c6d01042a9d61f717de5dfa.jpg
* Donkey Kong Country
* https://craftpix.net/product/2d-top-down-cave-tileset/?affiliate=134456
* https://brullov.itch.io/fire-animation/download/eyJpZCI6NTI5NDkxLCJleHBpcmVzIjoxNjcwNzMzNDkyfQ%3d%3d.K4Fsh0fAcWmN5our%2fHXqUXrW5dc%3d
* https://onocentaur.itch.io/potions/download/eyJpZCI6MTc1NTUyMiwiZXhwaXJlcyI6MTY3MDcyMzgzNn0%3d.Wh3CZdE%2f2C1%2f7zXJXD5td2q2XhE%3d
* https://jestan.itch.io/weapons-pack/download/eyJpZCI6MzY4MDQ5LCJleHBpcmVzIjoxNjcwNzIwNzE2fQ%3d%3d.pnha55eJqjbRMeVkNvTBz20XzOc%3d
