#pragma once
#include "Common.h"
#include "Scene.h"
#include <map>
#include <memory>

#include "EntityManager.h"
class WorldMap_View : public Scene
{

    struct PlayerConfig
    {
        float X, Y, CX, CY, SPEED;
    };

protected:
    std::shared_ptr<Entity> m_player;
    PlayerConfig            m_playerConfig;
    bool                    m_drawTextures = true;

    void sMovement();
    void spawnPlayer();
    void sAnimation();
    void sCollision();
    void sCamera();
    void init();
    void update();
    void onEnd();

public:

    WorldMap_View(GameEngine* gameEngine);

    void sRender();
    void sDoAction(const Action& action);
};

