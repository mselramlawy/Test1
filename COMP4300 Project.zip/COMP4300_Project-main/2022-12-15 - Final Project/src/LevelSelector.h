#pragma once

#include "Common.h"
#include "Scene.h"
#include <map>
#include <memory>
#include <deque>

#include "EntityManager.h"

class LevelSelector : public Scene
{

protected:
    std::vector<std::string>    m_menuStrings;
    sf::Text                    m_menuText;
    size_t                      m_selectedMenuIndex = 0;

    void init();
    void update();
    void onEnd();
    void bindActions();
    void sDoAction(const Action& action);

public:

    LevelSelector(GameEngine* gameEngine = nullptr);
    void sRender();

};
