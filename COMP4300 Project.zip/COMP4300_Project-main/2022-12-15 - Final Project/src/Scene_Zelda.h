///\/\/\\\\\//////\/\/\/\\\///\\\/\/\/\\\\\//////\/\/\/\\\///\\\
//
//  Assignment       COMP4300 - Assignment 4
//  Professor:       David Churchill
//  Year / Term:     2022-09
//  File Name:       Scene_Zelda.h
// 
//  Student Name:    Yeong Shu Chun
//  Student User:    yschun
//  Student Email:   yschun@mun.ca
//  Student ID:      201623048
//  Group Member(s): [enter student name(s)]
//
///\/\/\\\\\//////\/\/\/\\\///\\\/\/\/\\\\\//////\/\/\/\\\///\\\
                                                                          
#pragma once

#include "Common.h"
#include "Scene.h"
#include <map>
#include <memory>
                                                                          
#include "EntityManager.h"

class Scene_Zelda : public Scene
{

    struct PlayerConfig
    {
        float X, Y, CX, CY, SPEED, HEALTH;
        std::shared_ptr<WeaponConfig> WEAPON;
    };

protected:

    std::shared_ptr<Entity> m_player;
    std::string             m_levelPath;
    std::string             m_fileName = "";
    PlayerConfig            m_playerConfig;
    size_t					m_tileSize = 128;
    bool                    m_drawTextures = true;
    bool                    m_drawCollision = false;
    bool                    m_follow = false;
    std::map<std::string, std::shared_ptr<sf::Shader>> m_shaderMap;
    sf::Clock time;
    std::set<std::pair<int, int>> darkRooms;
    std::string m_prevScene;
    
    void init(const std::string & levelPath);

    void loadLevel(const std::string & filename);
    std::shared_ptr<WeaponConfig> loadWeaponConfig(std::string weaponName, std::ifstream& fin);
    void loadAIConfig(std::shared_ptr<Entity> entity, int rx, int ry, int tx, int ty, std::ifstream& fin);
    std::shared_ptr<sf::Shader> Scene_Zelda::getShader(const std::string& shaderName, const std::string& shaderPath);
    std::string getWeaponAnimation(std::shared_ptr<WeaponConfig> weapon);
    std::string getWeaponTexture(std::shared_ptr<WeaponConfig> weapon);
    std::string getItemTexture(std::shared_ptr<ItemConfig> item);


    void onEnd();
    void onGameOver();
    void update();
    void spawnPlayer();
    void bindActions();
    void spawnSword(std::shared_ptr<Entity> entity, int damage=1, int lifespan=10);
    void spawnBullet(std::shared_ptr<Entity> entity, float theta, int speed=5, int homingRadius = 0, int damage=1, int lifespan=120);
    void spawnLaser(std::shared_ptr<Entity> entity, int damage = 3, int lifespan = 30);
    std::shared_ptr<Entity> spawnProjectile(std::shared_ptr<Entity> entity, std::string animationName, float theta, int speed = 5, int homingRadius = 0, int damage = 1, int lifespan = 120, std::shared_ptr<sf::Shader> shader = nullptr);
    void spawnBombExplosion(std::shared_ptr<Entity> entity);
    void spawnPoisonPool(std::shared_ptr<Entity> entity);
    void attack(std::shared_ptr<Entity> entity);
    void useItem(std::shared_ptr<ItemConfig> item);
    void dodge(std::shared_ptr<Entity> entity);
    void fall(std::shared_ptr<Entity> entity);
    Vec2 getPosition(int sx, int sy, int tx, int ty) const;
    void updateSwordAnimation(std::shared_ptr<Entity> sword);
    void updateLaserAnimation(std::shared_ptr<Entity> laser);
    float getLightStrength(std::shared_ptr<Entity> entity);
    void destroyEnemy(std::shared_ptr<Entity> entity);
    void Scene_Zelda::startCombat();
    void applyStatuses(std::vector<std::string> statuses, std::shared_ptr<Entity> target);
    
    void sMovement();
    void sAI();
    Vec2 GetRoom(Vec2 pos);
    void checkCombat();
    void BossCombat();
    void doorLock(bool status);
    void sStatus();
    void sInventory();
    void sAnimation();
    void sCollision();
    void sCamera();
    void saveLevel();
    

public:

    Scene_Zelda(GameEngine* gameEngine, const std::string& levelPath, std::string prevScene = "");

    void sRender();
    void sDoAction(const Action& action);
};
                                                                          
// Copyright (C) David Churchill - All Rights Reserved
// COMP4300 - 2022-09 - Assignment 4
// Written by David Churchill (dave.churchill@gmail.com)
// Unauthorized copying of these files are strictly prohibited
// Distributed only for course work at Memorial University
// If you see this file online please contact email above
