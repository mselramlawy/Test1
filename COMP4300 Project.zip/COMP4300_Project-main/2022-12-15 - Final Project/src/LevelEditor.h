#pragma once

#include "Common.h"
#include "Scene.h"
#include <map>
#include <fstream>

#include "EntityManager.h"

typedef void(LevelEditor::* changeBoolFunc)(std::shared_ptr<Entity> m, bool& b, Action a);
typedef void(LevelEditor::* changeIntFunc)(std::shared_ptr<Entity> m, int& b, Action a);
typedef void(LevelEditor::* clickFunc)(std::shared_ptr<Entity> m, Action a);

class LevelEditor : public Scene
{
    struct BuildItemConfig {
        bool blockMove = false, blockVision = false;
        int bx = 0, by = 0;
        int health = 1, damage = 0;
        int weaponChoiceIdx = 0;
        int weaponDamage = 1, weaponCooldown = 0, weaponLifespan = 1, bulletSpeed = 1, bulletHomingRadius = 0;
        int movementChoiceIdx = 0;
        int speed = 1;
        std::vector<Vec2> patrolPositions;
        int keepDistRange = 1;
        bool hasEnraged = false;
        int healthThreshold = 1, speedMutiplier = 1, dmgMultiplier = 1;
        int consumableCount = 1;
    };
protected:
    sf::View m_mainView;
    sf::View m_rightPanelView;
    sf::View m_bottomPanelView;
    Vec2 m_mPos;
    Vec2 selectedOrigPos;
    std::shared_ptr<Entity> selectedEntity;
    sf::Font m_font;
    std::string m_levelPath;
    std::vector<std::string> weapons = {
        "none", "sword", "laser", "gun", "spreadgun", "shotgun"
    };
    std::vector<std::string> movements = {
        "none", "follow", "patrol", "keepdist"
    };
    std::map<std::string, BuildItemConfig> buildConfigMap;
    std::map<int, BuildItemConfig> placedConfigMap;
    std::map<std::string, std::string> weaponNameMap = {
        {"SwordRight", "sword"},
        {"Gun", "gun"},
        {"Shotgun", "shotgun"},
        {"Spreadgun", "spreadgun"},
        {"Laser", "laser"}
    };
    std::map<std::pair<int, int>, bool> darkRooms;
    sf::Shader darkShader;
    bool selectingPatrol = false;
    

    void init();
    void initViews();
    void initEntities();
    void update();
    void onEnd();
    void sDoAction(const Action& action);
    void renderEntity(std::shared_ptr<Entity> e);
    void renderMenuItem(std::shared_ptr<Entity> e);
    void moveCamera(Vec2 velocity);
    void buildMenu();
    Vec2 getBuildItemPosition(int i);
    Vec2 windowToMainView(const Vec2& window) const;
    Vec2 windowToRightView(const Vec2& window) const;
    Vec2 windowToBottomView(const Vec2& window) const;
    Vec2 getClosestGridPos(Vec2 pos);

    sf::Text getMenuText(std::string str);
    Vec2 getMenuPos(Vec2 gridPos, sf::Text menuText);

    bool& getBoolValForMenuItem(std::shared_ptr<Entity> menuItem);
    int& getIntValForMenuItem(std::shared_ptr<Entity> menuItem);

    void addBoolMenuItem(std::string id, std::string textStr, std::shared_ptr<Entity> entity, changeBoolFunc f, Vec2 gridPos);
    void addIntMenuItem(std::string id, std::string textStr, std::shared_ptr<Entity> entity, changeIntFunc f, Vec2 gridPos);
    void addChoiceMenuItem(std::string id, std::string textStr, std::shared_ptr<Entity> entity, Vec2 gridPos);
    void addClickMenuItem(std::string textStr, std::shared_ptr<Entity> entity, clickFunc f, Vec2 gridPos);
    void addWeaponMenuItems(std::string weaponName, std::shared_ptr<Entity> entity, Vec2 startingGridPos);
    void addMovementMenuItems(std::string weaponName, std::shared_ptr<Entity> entity, Vec2 startingGridPos);

    void toggleBool(std::shared_ptr<Entity> menuItem, bool& b, Action action);
    void changeNum(std::shared_ptr<Entity> menuItem, int& i, Action action);
    void cycleOptions(std::shared_ptr<Entity> menuItem, Action action);
    void selectPatrolPositions(std::shared_ptr<Entity> menuItem, Action action);
    void saveLevel(std::shared_ptr<Entity> menuItem, Action action);
    void testLevel(std::shared_ptr<Entity> menuItem, Action action);

    void writeToFile(std::string file);
    void writeValues(std::ofstream& f, std::vector<std::string> values);

public:

    LevelEditor(GameEngine* gameEngine, std::string levelPath);
    void sRender();
};