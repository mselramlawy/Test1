#include "LevelEditor.h"
#include "Common.h"
#include "Assets.h"
#include "GameEngine.h"
#include "Components.h"
#include "Action.h"
#include "Physics.h"
#include "Scene_Zelda.h"

LevelEditor::LevelEditor(GameEngine* gameEngine, std::string levelPath) : Scene(gameEngine), m_levelPath(levelPath)
{
    init();
}

void LevelEditor::init()
{
    registerAction(sf::Keyboard::W, "UP");
    registerAction(sf::Keyboard::S, "DOWN");
    registerAction(sf::Keyboard::A, "LEFT");
    registerAction(sf::Keyboard::D, "RIGHT");
    registerAction(sf::Keyboard::Escape, "QUIT");

    m_font = m_game->assets().getFont("Arial");

    if (!darkShader.loadFromFile("shaders/dark.frag", sf::Shader::Fragment))
    {
        std::cerr << "Could not load shader file: " << "shaders/dark.frag" << std::endl;
    }
    else
    {
        darkShader.setUniform("texture", sf::Shader::CurrentTexture);
        darkShader.setUniform("lightStrength", 0.5f);
        std::cout << "Loaded Shader:    " << "shaders/dark.frag" << std::endl;
    }

    initViews();
    initEntities();
}

void LevelEditor::initViews()
{
    m_mainView.reset(sf::FloatRect(0, 0, 960, 576));
    m_mainView.setViewport(sf::FloatRect(0, 0, 0.75, 0.75));
    m_rightPanelView.reset(sf::FloatRect(0, 0, 320.0f, 768.0f));
    m_rightPanelView.setViewport(sf::FloatRect(0.75, 0, 0.25, 1.0f));
    m_bottomPanelView.reset(sf::FloatRect(0, 0, 960, 192));
    m_bottomPanelView.setViewport(sf::FloatRect(0, 0.75, 0.75, 0.25));
}

void LevelEditor::initEntities()
{
    std::vector<std::string> tiles = {
        "MetalT",
        "MetalB",
        "MetalR",
        "MetalL",
        "MetalTR",
        "MetalTL",
        "MetalBR",
        "MetalBL",
        "MetalX",
        "MetalM",
        "MetalD",
        "EnterL",
        "EnterR",
        "EnterTL",
        "EnterTR",
        "Barrel",
        "Chest",
        "Water",
        "Box1",
        "Spawner",
        "Heart",
    };
    std::vector<std::string> npcs = {
        "Tektite",
        "Knight",
        "Boss",
        "MoveTile",
        "Enemy1",
        "Enemy2"
    };
    std::vector<std::string> items = {
        "HealthPot",
        "SpeedPot",
        "Bomb",
        "Poison"
    };
    std::vector<std::string> weapons = {
        "SwordRight",
        "Gun",
        "Shotgun",
        "Laser",
        "Spreadgun"
    };
    int i = 0;
    for (std::string animationName : tiles)
    {
        auto tile = m_entityManager.addEntity("builditem");
        auto animation = m_game->assets().getAnimation(animationName);
        tile->addComponent<CAnimation>(animation, true);
        tile->addComponent<CTransform>(getBuildItemPosition(i));
        tile->getComponent<CTransform>().scale = Vec2(0.8, 0.8);
        tile->addComponent<CBuildItem>("tile");
        buildConfigMap[animation.getName()] = BuildItemConfig();
        i++;
    }
    i += 5 - (i%5);
    for (std::string animationName : npcs)
    {
        auto npc = m_entityManager.addEntity("builditem");
        auto animation = m_game->assets().getAnimation(animationName);
        npc->addComponent<CAnimation>(animation, true);
        npc->addComponent<CTransform>(getBuildItemPosition(i));
        npc->getComponent<CTransform>().scale = Vec2(0.8, 0.8);
        npc->addComponent<CBuildItem>("npc");
        buildConfigMap[animation.getName()] = BuildItemConfig();
        i++;
    }
    i += 5 - (i % 5);
    for (std::string animationName : items)
    {
        auto item = m_entityManager.addEntity("builditem");
        auto animation = m_game->assets().getAnimation(animationName);
        item->addComponent<CAnimation>(animation, true);
        item->addComponent<CTransform>(getBuildItemPosition(i));
        item->getComponent<CTransform>().scale = Vec2(0.8, 0.8);
        item->addComponent<CBuildItem>("consumable");
        buildConfigMap[animation.getName()] = BuildItemConfig();
        i++;
    }
    i += 5 - (i % 5);
    for (std::string animationName : weapons)
    {
        auto weapon = m_entityManager.addEntity("builditem");
        auto animation = m_game->assets().getAnimation(animationName);
        weapon->addComponent<CAnimation>(animation, true);
        weapon->addComponent<CTransform>(getBuildItemPosition(i));
        weapon->getComponent<CTransform>().scale = Vec2(0.8, 0.8);
        weapon->addComponent<CBuildItem>("weapon");
        buildConfigMap[animation.getName()] = BuildItemConfig();
        i++;
    }

    auto player = m_entityManager.addEntity("placedentity");
    auto animation = m_game->assets().getAnimation("StandDown");
    player->addComponent<CAnimation>(animation, true);
    player->addComponent<CTransform>(Vec2(480, 288));
    player->getComponent<CTransform>().scale = Vec2(0.75, 0.75);
    player->addComponent<CBuildItem>("player");
    BuildItemConfig playerConfig = BuildItemConfig();
    playerConfig.bx = animation.getSize().x;
    playerConfig.by = animation.getSize().y;
    playerConfig.speed = 8;
    playerConfig.health = 10;
    playerConfig.weaponChoiceIdx = 3;
    playerConfig.weaponDamage = 1;
    playerConfig.weaponCooldown = 30;
    playerConfig.weaponLifespan = 60;
    playerConfig.bulletSpeed = 7;
    playerConfig.bulletHomingRadius = 0;
    placedConfigMap[player->id()] = playerConfig;
}



void LevelEditor::update()
{
    m_entityManager.update();
}

void LevelEditor::sDoAction(const Action& action)
{
    if (action.type() == "START")
    {
        int cameraSpeed = 15;
        if (action.name() == "UP")
        {
            moveCamera(Vec2(0, -cameraSpeed));
        }
        else if (action.name() == "DOWN")
        {
            moveCamera(Vec2(0, cameraSpeed));
        }
        else if (action.name() == "LEFT")
        {
            moveCamera(Vec2(-cameraSpeed, 0));
        }
        else if (action.name() == "RIGHT")
        {
            moveCamera(Vec2(cameraSpeed, 0));
        }
        else if (action.name() == "QUIT")
        {
            onEnd();
        }
        else if (action.name() == "LEFT_CLICK")
        {
            if (selectingPatrol && selectedEntity != nullptr)
            {
                auto& buildConfig = selectedEntity->tag() == "builditem" ? buildConfigMap[selectedEntity->getComponent<CAnimation>().animation.getName()] : placedConfigMap[selectedEntity->id()];
                Vec2 mainViewPos = windowToMainView(action.pos());
                buildConfig.patrolPositions.push_back(Vec2(mainViewPos.x / 48, mainViewPos.y / 48));
            }
            else
            {
                for (auto e : m_entityManager.getEntities("builditem"))
                {
                    if (Physics::IsInside(windowToRightView(action.pos()), e))
                    {
                        selectedEntity = e;
                    }
                }
                for (auto e : m_entityManager.getEntities("placedentity"))
                {
                    if (Physics::IsInside(windowToMainView(action.pos()), e))
                    {
                        selectedEntity = e;
                    }
                }
                for (auto e : m_entityManager.getEntities("menuitem"))
                {
                    if (e->hasComponent<CMenuItem>() && e->getComponent<CMenuItem>().boolFunc != nullptr && Physics::IsInside(windowToBottomView(action.pos()), e))
                    {
                        auto f = e->getComponent<CMenuItem>().boolFunc;
                        (this->*f)(e, getBoolValForMenuItem(e), action);
                    }
                    if (e->hasComponent<CMenuItem>() && e->getComponent<CMenuItem>().numFunc != nullptr && Physics::IsInside(windowToBottomView(action.pos()), e))
                    {
                        auto f = e->getComponent<CMenuItem>().numFunc;
                        (this->*f)(e, getIntValForMenuItem(e), action);
                    }
                    if (e->hasComponent<CMenuItem>() && e->getComponent<CMenuItem>().clickFunc != nullptr && Physics::IsInside(windowToBottomView(action.pos()), e))
                    {
                        auto f = e->getComponent<CMenuItem>().clickFunc;
                        (this->*f)(e, action);
                    }
                }
            }
        }
        else if (action.name() == "RIGHT_CLICK")
        {
            if (selectingPatrol)
            {
                selectingPatrol = false;
            }
            else if (selectedEntity != nullptr)
            {
                selectedEntity = nullptr;
            }
            else
            {
                for (auto e : m_entityManager.getEntities("menuitem"))
                {
                    if (e->hasComponent<CMenuItem>() && e->getComponent<CMenuItem>().boolFunc != nullptr && Physics::IsInside(windowToBottomView(action.pos()), e))
                    {
                        auto f = e->getComponent<CMenuItem>().boolFunc;
                        (this->*f)(e, getBoolValForMenuItem(e), action);
                    }
                    if (e->hasComponent<CMenuItem>() && e->getComponent<CMenuItem>().numFunc != nullptr && Physics::IsInside(windowToBottomView(action.pos()), e))
                    {
                        auto f = e->getComponent<CMenuItem>().numFunc;
                        (this->*f)(e, getIntValForMenuItem(e), action);
                    }
                    if (e->hasComponent<CMenuItem>() && e->getComponent<CMenuItem>().clickFunc != nullptr && Physics::IsInside(windowToBottomView(action.pos()), e))
                    {
                        auto f = e->getComponent<CMenuItem>().clickFunc;
                        (this->*f)(e, action);
                    }
                }
                for (auto e : m_entityManager.getEntities("placedentity"))
                {
                    if (e->getComponent<CBuildItem>().type != "player" && Physics::IsInside(windowToMainView(action.pos()), e))
                    {
                        e->destroy();
                    }
                }
            }
        }
        else if (action.name() == "MOUSE_MOVE")
        {
            m_mPos = action.pos();
        }
        else if (action.name() == "MIDDLE_CLICK")
        {
            if (selectedEntity != nullptr)
            {
                Vec2 mainViewPos = windowToMainView(action.pos());
                if (selectedEntity->tag() == "builditem")
                {
                    auto& placedEntity = m_entityManager.addEntity("placedentity");
                    placedEntity->addComponent<CTransform>(getClosestGridPos(mainViewPos));
                    placedEntity->getComponent<CTransform>().scale = Vec2(0.75, 0.75);
                    placedEntity->addComponent<CAnimation>(selectedEntity->getComponent<CAnimation>().animation, selectedEntity->getComponent<CAnimation>().repeat);
                    placedEntity->addComponent<CBuildItem>(selectedEntity->getComponent<CBuildItem>().type);
                    placedConfigMap[placedEntity->id()] = buildConfigMap[selectedEntity->getComponent<CAnimation>().animation.getName()];
                }
                else if (selectedEntity->tag() == "placedentity")
                {
                    selectedEntity->getComponent<CTransform>().pos = getClosestGridPos(mainViewPos);
                }
            }
        }
        else if (action.name() == "WHEEL_SCROLL")
        {
            for (auto e : m_entityManager.getEntities("menuitem"))
            {
                if (e->hasComponent<CMenuItem>() && e->getComponent<CMenuItem>().numFunc != nullptr && Physics::IsInside(windowToBottomView(action.pos()), e))
                {
                    auto f = e->getComponent<CMenuItem>().numFunc;
                    (this->*f)(e, getIntValForMenuItem(e), action);
                }
                if (e->hasComponent<CMenuItem>() && e->getComponent<CMenuItem>().clickFunc != nullptr && Physics::IsInside(windowToBottomView(action.pos()), e))
                {
                    auto f = e->getComponent<CMenuItem>().clickFunc;
                    (this->*f)(e, action);
                }
            }
        }
    }
}

Vec2 LevelEditor::getBuildItemPosition(int i)
{
    int tx = i % 5;
    int ty = i / 5;
    int x = tx * 64 + 32;
    int y = ty * 64 + 32;

    return Vec2(x, y);
}

void LevelEditor::sRender()
{
    m_game->window().clear(sf::Color(72, 50, 72));

    m_game->window().setView(m_mainView);
    std::shared_ptr<Entity> playerEntity;
    for (auto& e : m_entityManager.getEntities("placedentity"))
    {
        if (e->getComponent<CBuildItem>().type != "player")
        {
            renderEntity(e);
        }
        else
        {
            playerEntity = e;
        }
        if (e == selectedEntity)
        {
            Vec2 size = Vec2(46, 46);
            Vec2 pos = e->getComponent<CTransform>().pos;
            sf::RectangleShape rect({ size.x, size.y });
            rect.setPosition({ pos.x, pos.y });
            rect.setOrigin({ size.x / 2, size.y / 2 });
            rect.setOutlineColor(sf::Color::Red);
            rect.setOutlineThickness(3);
            rect.setFillColor(sf::Color::Transparent);
            m_game->window().draw(rect);
        }
    }
    renderEntity(playerEntity);


    int rx = floor(m_mainView.getCenter().x / 960);
    int ry = floor(m_mainView.getCenter().y / 576);
    sf::RectangleShape room({ 960, 576 });
    room.setPosition(rx*960, ry*576);
    room.setOutlineColor(sf::Color::Black);
    room.setOutlineThickness(4);
    room.setFillColor(sf::Color::Transparent);
    m_game->window().draw(room);


    m_game->window().setView(m_rightPanelView);
    sf::RectangleShape rightBorder({ 320, 768 });
    rightBorder.setOutlineThickness(4);
    rightBorder.setPosition(4, 4);
    rightBorder.setOutlineColor(sf::Color(50, 50, 150));
    rightBorder.setFillColor(sf::Color::Transparent);
    m_game->window().draw(rightBorder);
    for (auto& e : m_entityManager.getEntities("builditem"))
    {
        if (e->hasComponent<CAnimation>())
        {
            renderEntity(e);
            if (e == selectedEntity)
            {
                Vec2 size = Vec2(56, 56);
                Vec2 pos = e->getComponent<CTransform>().pos;
                sf::RectangleShape rect({ size.x, size.y });
                rect.setPosition({ pos.x, pos.y });
                rect.setOrigin({ size.x / 2, size.y / 2 });
                rect.setOutlineColor(sf::Color::Red);
                rect.setOutlineThickness(3);
                rect.setFillColor(sf::Color::Transparent);
                m_game->window().draw(rect);
            }
        }
    }

    m_game->window().setView(m_bottomPanelView);
    sf::RectangleShape bottomBorder({ 952, 184 });
    bottomBorder.setOutlineThickness(4);
    bottomBorder.setPosition(4, 4);
    bottomBorder.setOutlineColor(sf::Color(50, 50, 150));
    bottomBorder.setFillColor(sf::Color::Transparent);
    m_game->window().draw(bottomBorder);
    buildMenu();
    for (auto& e : m_entityManager.getEntities("menuitem"))
    {
        renderMenuItem(e);
    }
}

void LevelEditor::renderEntity(std::shared_ptr<Entity> e)
{
    sf::Color c = sf::Color::White;
    auto& animation = e->getComponent<CAnimation>().animation;
    auto& eTrans = e->getComponent<CTransform>();
    animation.getSprite().setRotation(eTrans.angle);
    animation.getSprite().setPosition(eTrans.pos.x, eTrans.pos.y);
    animation.getSprite().setScale(eTrans.scale.x, eTrans.scale.y);
    animation.getSprite().setColor(c);
    int rx = floor(eTrans.pos.x / 960);
    int ry = floor(eTrans.pos.y / 576);
    auto room = std::make_pair(rx, ry);
    bool isInDarkRoom = darkRooms.find(room) == darkRooms.end() ? false : darkRooms[room];

    if (isInDarkRoom && e->tag() == "placedentity")
    {
        m_game->window().draw(animation.getSprite(), &darkShader);
    }
    else
    {
        m_game->window().draw(animation.getSprite());
    }
}

void LevelEditor::renderMenuItem(std::shared_ptr<Entity> e)
{
    sf::Color c = sf::Color::White;
    auto& eTrans = e->getComponent<CTransform>();
    e->getComponent<CMenuItem>().text.setPosition((int)eTrans.pos.x, (int)eTrans.pos.y);
    if (e->hasComponent<CShader>())
    {
        sf::Shader& shader = *e->getComponent<CShader>().shader;
        m_game->window().draw(e->getComponent<CMenuItem>().text, &*e->getComponent<CShader>().shader);
    }
    else
    {
        m_game->window().draw(e->getComponent<CMenuItem>().text);
    }
}

void LevelEditor::moveCamera(Vec2 velocity)
{
    auto currCenter = m_mainView.getCenter();
    m_mainView.setCenter(currCenter.x + velocity.x, currCenter.y + velocity.y);
}

void LevelEditor::buildMenu()
{
    for (auto& e : m_entityManager.getEntities("menuitem"))
    {
        e->destroy();
    }

    if (selectedEntity != nullptr)
    {
        std::string animationName = selectedEntity->getComponent<CAnimation>().animation.getName();
        auto& eBuildItem = selectedEntity->getComponent<CBuildItem>();
        auto& config = selectedEntity->tag() == "builditem" ? buildConfigMap[animationName] : placedConfigMap[selectedEntity->id()];
        if (eBuildItem.type == "tile")
        {
            addBoolMenuItem("bm", "Block Move: " + std::to_string(config.blockMove), selectedEntity, &LevelEditor::toggleBool, Vec2(0, 0));
            addBoolMenuItem("bv", "Block Vision: " + std::to_string(config.blockVision), selectedEntity, &LevelEditor::toggleBool, Vec2(0, 1));
        }
        else if (eBuildItem.type == "npc")
        {
            addBoolMenuItem("bm", "Block Move : " + std::to_string(config.blockMove), selectedEntity, &LevelEditor::toggleBool, Vec2(0, 0));
            addBoolMenuItem("bv", "Block Vision: " + std::to_string(config.blockVision), selectedEntity, &LevelEditor::toggleBool, Vec2(0, 1));
            addIntMenuItem("h", "Max Health: " + std::to_string(config.health), selectedEntity, &LevelEditor::changeNum, Vec2(0, 2));
            addIntMenuItem("d", "Damage: " + std::to_string(config.damage), selectedEntity, &LevelEditor::changeNum, Vec2(0, 3));
            addChoiceMenuItem("weapon", "Weapon: " + weapons[config.weaponChoiceIdx], selectedEntity, Vec2(1, 0));
            addWeaponMenuItems(weapons[config.weaponChoiceIdx], selectedEntity, Vec2(1, 1));
            addChoiceMenuItem("movement", "Movement: " + movements[config.movementChoiceIdx], selectedEntity, Vec2(2, 0));
            addMovementMenuItems(movements[config.movementChoiceIdx], selectedEntity, Vec2(2, 1));
            addBoolMenuItem("he", "Enrage: " + std::to_string(config.hasEnraged), selectedEntity, &LevelEditor::toggleBool, Vec2(3, 0));
            if (config.hasEnraged)
            {
                addIntMenuItem("ht", "Health Threshold: " + std::to_string(config.healthThreshold), selectedEntity, &LevelEditor::changeNum, Vec2(3, 1));
                addIntMenuItem("sm", "Speed Multiplier: " + std::to_string(config.speedMutiplier), selectedEntity, &LevelEditor::changeNum, Vec2(3, 2));
                addIntMenuItem("dm", "Dmg Multiplier: " + std::to_string(config.dmgMultiplier), selectedEntity, &LevelEditor::changeNum, Vec2(3, 3));
            }
        }
        else if (eBuildItem.type == "consumable")
        {
            addIntMenuItem("ic", "Count: " + std::to_string(config.consumableCount), selectedEntity, &LevelEditor::changeNum, Vec2(0, 0));
        }
        else if (eBuildItem.type == "weapon")
        {
            addWeaponMenuItems(weaponNameMap[animationName], selectedEntity, Vec2(0, 0));
        }
        else if (eBuildItem.type == "player")
        {
            addIntMenuItem("bx", "Bounding Box Size X: " + std::to_string(config.bx), selectedEntity, &LevelEditor::changeNum, Vec2(0, 0));
            addIntMenuItem("by", "Bounding Box Size Y: " + std::to_string(config.by), selectedEntity, &LevelEditor::changeNum, Vec2(0, 1));
            addIntMenuItem("s", "Speed: " + std::to_string(config.speed), selectedEntity, &LevelEditor::changeNum, Vec2(0, 2));
            addIntMenuItem("h", "Max Health: " + std::to_string(config.health), selectedEntity, &LevelEditor::changeNum, Vec2(0, 3));
            addChoiceMenuItem("weapon", "Weapon: " + weapons[config.weaponChoiceIdx], selectedEntity, Vec2(2, 0));
            addWeaponMenuItems(weapons[config.weaponChoiceIdx], selectedEntity, Vec2(2, 1));
        }
    }

    int rx = floor(m_mainView.getCenter().x / 960);
    int ry = floor(m_mainView.getCenter().y / 576);
    auto room = std::make_pair(rx, ry);
    bool isDark = darkRooms.find(room) == darkRooms.end() ? false : darkRooms[room];
    addBoolMenuItem("dr", "Dark Room: " + std::to_string(isDark), nullptr, &LevelEditor::toggleBool, Vec2(5,1));
    addClickMenuItem("Save", nullptr, &LevelEditor::saveLevel, Vec2(5, 3));
    addClickMenuItem("Test", nullptr, &LevelEditor::testLevel, Vec2(5, 5));
}

bool& LevelEditor::getBoolValForMenuItem(std::shared_ptr<Entity> menuItem)
{
    std::string id = menuItem->getComponent<CMenuItem>().id;
    if (id == "dr") {
        int rx = floor(m_mainView.getCenter().x / 960);
        int ry = floor(m_mainView.getCenter().y / 576);
        auto room = std::make_pair(rx, ry);
        if (darkRooms.find(room) == darkRooms.end())
        {
            darkRooms[room] = false;
        }
        return darkRooms[room];
    }

    auto& e = menuItem->getComponent<CMenuItem>().entity;
    auto& buildConfig = e->tag() == "builditem" ? buildConfigMap[e->getComponent<CAnimation>().animation.getName()] : placedConfigMap[e->id()];
    if (id == "bm") { return buildConfig.blockMove; }
    else if (id == "bv") { return buildConfig.blockVision; }
    else if (id == "he") { return buildConfig.hasEnraged; }
}

int& LevelEditor::getIntValForMenuItem(std::shared_ptr<Entity> menuItem)
{
    auto& e = menuItem->getComponent<CMenuItem>().entity;
    std::string id = menuItem->getComponent<CMenuItem>().id;
    auto& buildConfig = e->tag() == "builditem" ? buildConfigMap[e->getComponent<CAnimation>().animation.getName()] : placedConfigMap[e->id()];
    if (id == "h") { return buildConfig.health; }
    else if (id == "d") { return buildConfig.damage; }
    else if (id == "wd") { return buildConfig.weaponDamage; }
    else if (id == "wc") { return buildConfig.weaponCooldown; }
    else if (id == "wl") { return buildConfig.weaponLifespan; }
    else if (id == "bs") { return buildConfig.bulletSpeed; }
    else if (id == "bh") { return buildConfig.bulletHomingRadius; }
    else if (id == "s") { return buildConfig.speed; }
    else if (id == "kd") { return buildConfig.keepDistRange; }
    else if (id == "ht") { return buildConfig.healthThreshold; }
    else if (id == "sm") { return buildConfig.speedMutiplier; }
    else if (id == "dm") { return buildConfig.dmgMultiplier; }
    else if (id == "ic") { return buildConfig.consumableCount; }
    else if (id == "bx") { return buildConfig.bx; }
    else if (id == "by") { return buildConfig.by; }

}

void LevelEditor::addBoolMenuItem(std::string id, std::string textStr, std::shared_ptr<Entity> entity, changeBoolFunc f, Vec2 gridPos)
{
    auto item = m_entityManager.addEntity("menuitem");
    sf::Text text = getMenuText(textStr);
    item->addComponent<CMenuItem>(id, text, entity, f);
    item->addComponent<CTransform>(getMenuPos(gridPos, text));
    item->addComponent<CBoundingBox>(Vec2(text.getLocalBounds().width, text.getLocalBounds().height));
}

void LevelEditor::addIntMenuItem(std::string id, std::string textStr, std::shared_ptr<Entity> entity, changeIntFunc f, Vec2 gridPos)
{
    auto item = m_entityManager.addEntity("menuitem");
    sf::Text text = getMenuText(textStr);
    item->addComponent<CMenuItem>(id, text, entity, f);
    item->addComponent<CTransform>(getMenuPos(gridPos, text));
    item->addComponent<CBoundingBox>(Vec2(text.getLocalBounds().width, text.getLocalBounds().height));
}

void LevelEditor::addChoiceMenuItem(std::string id, std::string textStr, std::shared_ptr<Entity> entity, Vec2 gridPos)
{
    auto item = m_entityManager.addEntity("menuitem");
    sf::Text text = getMenuText(textStr);
    item->addComponent<CMenuItem>(id, text, entity, &LevelEditor::cycleOptions);
    item->addComponent<CTransform>(getMenuPos(gridPos, text));
    item->addComponent<CBoundingBox>(Vec2(text.getLocalBounds().width, text.getLocalBounds().height));
}

void LevelEditor::addClickMenuItem(std::string textStr, std::shared_ptr<Entity> entity, clickFunc f, Vec2 gridPos)
{
    auto item = m_entityManager.addEntity("menuitem");
    sf::Text text = getMenuText(textStr);
    item->addComponent<CMenuItem>(textStr, text, entity, f);
    item->addComponent<CTransform>(getMenuPos(gridPos, text));
    item->addComponent<CBoundingBox>(Vec2(text.getLocalBounds().width, text.getLocalBounds().height));
}

void LevelEditor::addWeaponMenuItems(std::string weaponName, std::shared_ptr<Entity> entity, Vec2 startingGridPos)
{
    std::string animationName = entity->getComponent<CAnimation>().animation.getName();
    auto& config = entity->tag() == "builditem" ? buildConfigMap[animationName] : placedConfigMap[entity->id()];
    if (weaponName == "none")
    {
        return;
    }
    else
    {
        addIntMenuItem("wd", "Damage: " + std::to_string(config.weaponDamage), entity, &LevelEditor::changeNum, startingGridPos);
        addIntMenuItem("wc", "Cooldown: " + std::to_string(config.weaponCooldown), entity, &LevelEditor::changeNum, startingGridPos + Vec2(0, 1));
        addIntMenuItem("wl", "Lifespan: " + std::to_string(config.weaponLifespan), entity, &LevelEditor::changeNum, startingGridPos + Vec2(0, 2));
        if (weaponName == "gun" || weaponName == "spreadgun" || weaponName == "shotgun")
        {
            addIntMenuItem("bs", "Bullet Speed: " + std::to_string(config.bulletSpeed), entity, &LevelEditor::changeNum, startingGridPos + Vec2(0, 3));
            addIntMenuItem("bh", "Homing Radius: " + std::to_string(config.bulletHomingRadius), entity, &LevelEditor::changeNum, startingGridPos + Vec2(0, 4));
        }
    }
}

void LevelEditor::addMovementMenuItems(std::string movement, std::shared_ptr<Entity> entity, Vec2 startingGridPos)
{
    std::string animationName = entity->getComponent<CAnimation>().animation.getName();
    auto& config = entity->tag() == "builditem" ? buildConfigMap[animationName] : placedConfigMap[entity->id()];
    if (movement == "none")
    {
        return;
    }
    else
    {
        addIntMenuItem("s", "Speed: " + std::to_string(config.speed), entity, &LevelEditor::changeNum, startingGridPos);
        if (movement == "patrol")
        {
            std::string patrolPoints = selectingPatrol ? "Selecting Patrol:\n" : "Patrol Points:\n";
            int i = 0;
            for (auto& p : config.patrolPositions)
            {
                patrolPoints += " (" + std::to_string((int)p.x) + ", " + std::to_string((int)p.y) + ")\n";
                if (++i >= 3 && config.patrolPositions.size() > 3)
                {
                    patrolPoints += "...";
                    break;
                }
            }
            addClickMenuItem(patrolPoints, entity, &LevelEditor::selectPatrolPositions, startingGridPos + Vec2(0, 1));
        }
        else if (movement == "keepdist")
        {
            addIntMenuItem("kd", "Distance: " + std::to_string(config.keepDistRange), entity, &LevelEditor::changeNum, startingGridPos + Vec2(0, 1));
        }
    }
}


sf::Text LevelEditor::getMenuText(std::string str)
{
    sf::Text text = sf::Text(str, m_font, 16);
    text.setOrigin((int)(text.getLocalBounds().width / 2), (int)(text.getLocalBounds().height / 2));
    return text;
}

Vec2 LevelEditor::getMenuPos(Vec2 gridPos, sf::Text menuText)
{
    int w = menuText.getLocalBounds().width;
    int h = menuText.getLocalBounds().height;
    return Vec2(gridPos.x*150 + w / 2 + 32, gridPos.y*16 + h / 2 + 32);
}

void LevelEditor::toggleBool(std::shared_ptr<Entity> menuItem, bool& b, Action action)
{
    b = !b;
}

void LevelEditor::changeNum(std::shared_ptr<Entity> menuItem, int &i, Action action)
{
    std::string actionName = action.name();
    if (actionName == "LEFT_CLICK")
    {
        i+=1;
    }
    else if (actionName == "RIGHT_CLICK" && i > 0)
    {
        i-=1;
    }
    else if (actionName == "WHEEL_SCROLL")
    {
        i = std::max(0, i + 10 * (action.scroll() < 0 ? -1 : 1));
    }
}

void LevelEditor::cycleOptions(std::shared_ptr<Entity> menuItem, Action action)
{
    std::string actionName = action.name();
    std::string id = menuItem->getComponent<CMenuItem>().id;
    auto& e = menuItem->getComponent<CMenuItem>().entity;
    auto& buildConfig = e->tag() == "builditem" ? buildConfigMap[e->getComponent<CAnimation>().animation.getName()] : placedConfigMap[e->id()];
    int incr = (actionName == "LEFT_CLICK" || (actionName == "WHEEL_SCROLL" && action.scroll() > 0)) ? 1 : -1;
    if (id == "weapon")
    {
        buildConfig.weaponChoiceIdx = (buildConfig.weaponChoiceIdx + incr) % weapons.size();
    }
    else if (id == "movement")
    {
        buildConfig.movementChoiceIdx = (buildConfig.movementChoiceIdx + incr) % movements.size();
    }
}

void LevelEditor::selectPatrolPositions(std::shared_ptr<Entity> menuItem, Action action)
{
    std::string actionName = action.name();
    auto& e = menuItem->getComponent<CMenuItem>().entity;
    auto& buildConfig = e->tag() == "builditem" ? buildConfigMap[e->getComponent<CAnimation>().animation.getName()] : placedConfigMap[e->id()];
    if (actionName == "LEFT_CLICK" && !selectingPatrol)
    {
        selectingPatrol = true;
        buildConfig.patrolPositions.clear();
    }
}

void LevelEditor::saveLevel(std::shared_ptr<Entity> menuItem, Action action)
{
    writeToFile(m_levelPath);
    onEnd();
}

void LevelEditor::testLevel(std::shared_ptr<Entity> menuItem, Action action)
{
    std::string tmpfile = std::tmpnam(nullptr);
    writeToFile(tmpfile);
    m_game->window().setView(m_game->window().getDefaultView());
    m_game->changeScene("WORLD", std::make_shared<Scene_Zelda>(m_game, tmpfile, "LEVEL_EDITOR"), false);
}

Vec2 LevelEditor::windowToMainView(const Vec2& window) const
{
    float wx = m_mainView.getCenter().x - (m_mainView.getSize().x / 2);
    float wy = m_mainView.getCenter().y - (m_mainView.getSize().y / 2);

    return Vec2(window.x + wx, window.y + wy);
}
Vec2 LevelEditor::windowToRightView(const Vec2& window) const
{
    return Vec2(window.x - m_mainView.getSize().x, window.y);
}

Vec2 LevelEditor::windowToBottomView(const Vec2& window) const
{
    return Vec2(window.x, window.y - m_mainView.getSize().y);
}

Vec2 LevelEditor::getClosestGridPos(Vec2 pos)
{
    int x = floor(pos.x / 48);
    int y = floor(pos.y / 48);
    return Vec2(x * 48 + 24, y * 48 + 24);
}

void LevelEditor::writeToFile(std::string file)
{
    std::map<std::string, std::string> movementBehaviorMap = {
        {"follow", "Follow"},
        {"patrol", "Patrol"},
        {"keepdist", "KeepDistance"}
    };

    std::map<std::string, std::string> consumableMap = {
        {"HealthPot", "health" },
        {"SpeedPot", "speed"},
        {"Bomb", "bomb"},
        {"Poison", "poison"}
    };

    std::ofstream f(file);
    for (auto& [k, v] : darkRooms)
    {
        if (v)
        {
            f << "DarkRoom " << k.first << " " << k.second << std::endl;
        }
    }

    for (auto& e : m_entityManager.getEntities("placedentity"))
    {
        auto& config = placedConfigMap[e->id()];
        std::string type = e->getComponent<CBuildItem>().type;
        std::string animationName = e->getComponent<CAnimation>().animation.getName();
        Vec2 pos = e->getComponent<CTransform>().pos;
        int rx = floor(pos.x / 960);
        int ry = floor(pos.y / 576);
        int tx = pos.x / 48;
        int ty = pos.y / 48;

        if (type == "tile")
        {
            f << "Tile";
            writeValues(f, { animationName, std::to_string(rx), std::to_string(ry), std::to_string(tx), std::to_string(ty),
                std::to_string(config.blockMove), std::to_string(config.blockVision) });
            f << std::endl;
        }
        else if (type == "npc")
        {
            f << "NPC";
            std::string weaponName = weapons[config.weaponChoiceIdx];
            writeValues(f, { animationName, std::to_string(rx), std::to_string(ry), std::to_string(tx), std::to_string(ty),
                std::to_string(config.blockMove), std::to_string(config.blockVision),
                std::to_string(config.health), std::to_string(config.damage), weaponName });
            if (weaponName != "none")
            {
                writeValues(f, { std::to_string(config.weaponDamage), std::to_string(config.weaponCooldown), std::to_string(config.weaponLifespan) });
                if (weaponName == "gun" || weaponName == "shotgun" || weaponName == "spreadgun")
                {
                    writeValues(f, { std::to_string(config.bulletSpeed), std::to_string(config.bulletHomingRadius) });
                }
            }
            std::string movement = movements[config.movementChoiceIdx];
            if (movement != "none" && !(movement == "patrol" && config.patrolPositions.size() == 0))
            {
                writeValues(f, { movementBehaviorMap[movement], std::to_string(config.speed) });
                if (movement == "patrol")
                {
                    writeValues(f, {std::to_string(config.patrolPositions.size())});
                    for (Vec2 p : config.patrolPositions)
                    {
                        writeValues(f, { std::to_string((int)p.x), std::to_string((int)p.y)});
                    }
                }
                else if (movement == "keepdist")
                {
                    writeValues(f, { std::to_string(config.keepDistRange) });
                }
            }
            if (config.hasEnraged)
            {
                writeValues(f, { "Enraged", std::to_string(config.healthThreshold), std::to_string(config.speedMutiplier), std::to_string(config.dmgMultiplier) });
            }
            f << " End" << std::endl;
        }
        else if (type == "consumable")
        {
            f << "Item";
            writeValues(f, { animationName, std::to_string(rx), std::to_string(ry), std::to_string(tx), std::to_string(ty),
                "Consumable", consumableMap[animationName], std::to_string(config.consumableCount) });
            f << std::endl;
        }
        else if (type == "weapon")
        {
            std::string weaponName = weaponNameMap[animationName];
            f << "Item";
            writeValues(f, { animationName, std::to_string(rx), std::to_string(ry), std::to_string(tx), std::to_string(ty),
                "Weapon", weaponName });
            writeValues(f, { std::to_string(config.weaponDamage), std::to_string(config.weaponCooldown), std::to_string(config.weaponLifespan) });
            if (weaponName == "gun" || weaponName == "shotgun" || weaponName == "spreadgun")
            {
                writeValues(f, { std::to_string(config.bulletSpeed), std::to_string(config.bulletHomingRadius) });
            }
            f << std::endl;
        }
        else if (type == "player")
        {
            std::string weaponName = weapons[config.weaponChoiceIdx];
            f << "Player";
            writeValues(f, { std::to_string((int)(pos.x/0.75)), std::to_string((int)(pos.y/0.75)), std::to_string(config.bx), std::to_string(config.by),
                std::to_string(config.speed), std::to_string(config.health), weaponName });
            if (weaponName != "none")
            {
                writeValues(f, { std::to_string(config.weaponDamage), std::to_string(config.weaponCooldown), std::to_string(config.weaponLifespan) });
                if (weaponName == "gun" || weaponName == "shotgun" || weaponName == "spreadgun")
                {
                    writeValues(f, { std::to_string(config.bulletSpeed), std::to_string(config.bulletHomingRadius) });
                }
            }
            f << std::endl;
        }
    }
    f.close();
}

void LevelEditor::writeValues(std::ofstream& f, std::vector<std::string> values)
{
    for (std::string s : values)
    {
        f << " " << s;
    }
}

void LevelEditor::onEnd()
{
    m_game->playSound("MusicTitle");
    m_game->changeScene("MENU", nullptr, true);
}
