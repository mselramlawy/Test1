#include "worldmap_view.h"
#include "Common.h"
#include "Physics.h"
#include "Assets.h"
#include "GameEngine.h"
#include "Components.h"
#include "Scene_Menu.h"
#include "Scene_Zelda.h"

WorldMap_View::WorldMap_View(GameEngine* game) : Scene(game)
{
    init();
}

void WorldMap_View::init()
{
    registerAction(sf::Keyboard::Escape, "QUIT");
    registerAction(sf::Keyboard::W, "UP");
    registerAction(sf::Keyboard::A, "LEFT");
    registerAction(sf::Keyboard::S, "DOWN");
    registerAction(sf::Keyboard::D, "RIGHT");
    registerAction(sf::Keyboard::E, "START");


    auto bck0 = m_entityManager.addEntity("bck1");
    bck0->addComponent<CAnimation>(m_game->assets().getAnimation("Smoke"), true);
    bck0->addComponent<CTransform>(Vec2(m_game->window().getSize().y -120, m_game->window().getSize().y-448));


    auto bck00 = m_entityManager.addEntity("bck1");
    bck00->addComponent<CAnimation>(m_game->assets().getAnimation("Skyline"), true);
    bck00->addComponent<CTransform>(Vec2(m_game->window().getSize().y - 120, m_game->window().getSize().y - 448));

    auto bck1 = m_entityManager.addEntity("bck1");
    Animation animation0 = m_game->assets().getAnimation("Factory");
    bck1->addComponent<CAnimation>(animation0, true);
    bck1->addComponent<CTransform>(Vec2(m_game->window().getSize().y - 120, m_game->window().getSize().y - 200));

    for (int tileNumber = 0; tileNumber < 30; tileNumber++)
    {
        auto tile = m_entityManager.addEntity("tile");
        auto x = tileNumber * 64 + 32;
        auto y = m_game->window().getSize().y - 32;
        Animation animation = m_game->assets().getAnimation("MetalX");
        tile->addComponent<CAnimation>(animation, true);
        tile->addComponent<CTransform>(Vec2(x, y));
        tile->addComponent<CBoundingBox>(animation.getSize(), true, true);
    }
    auto tile1 = m_entityManager.addEntity("tile");
    Animation animation1 = m_game->assets().getAnimation("Lvl1");
    tile1->addComponent<CAnimation>(animation1, true);
    tile1->addComponent<CTransform>(Vec2(300, m_game->window().getSize().y - 32 - 128));

    auto tile2 = m_entityManager.addEntity("tile");
    Animation animation2 = m_game->assets().getAnimation("Lvl2");
    tile2->addComponent<CAnimation>(animation2, true);
    tile2->addComponent<CTransform>(Vec2(600, m_game->window().getSize().y - 32 - 128));

    auto tile3 = m_entityManager.addEntity("tile");
    Animation animation3 = m_game->assets().getAnimation("Lvl3");
    tile3->addComponent<CAnimation>(animation3, true);
    tile3->addComponent<CTransform>(Vec2(900, m_game->window().getSize().y - 32 - 128));

    auto tile4 = m_entityManager.addEntity("level1");
    Animation animation4 = m_game->assets().getAnimation("Door1");
    tile4->addComponent<CAnimation>(animation4, true);
    tile4->addComponent<CTransform>(Vec2(300, m_game->window().getSize().y - 32 - 64));

    auto tile5 = m_entityManager.addEntity("level2");
    Animation animation5 = m_game->assets().getAnimation("Door1");
    tile5->addComponent<CAnimation>(animation5, true);
    tile5->addComponent<CTransform>(Vec2(600, m_game->window().getSize().y - 32 - 64));

    auto tile6 = m_entityManager.addEntity("level3");
    Animation animation6 = m_game->assets().getAnimation("Door1");
    tile6->addComponent<CAnimation>(animation6, true);
    tile6->addComponent<CTransform>(Vec2(900, m_game->window().getSize().y - 32 - 64));


    // Building Here
    auto tile7 = m_entityManager.addEntity("tile");
    Animation animation7 = m_game->assets().getAnimation("Building1");
    tile7->addComponent<CAnimation>(animation7, true);
    tile7->addComponent<CTransform>(Vec2(100, m_game->window().getSize().y - 32 - 64-64));


    auto tile8 = m_entityManager.addEntity("tile");
    Animation animation8 = m_game->assets().getAnimation("Building2");
    tile8->addComponent<CAnimation>(animation8, true);
    tile8->addComponent<CTransform>(Vec2(1100, m_game->window().getSize().y - 32 - 64 - 64));

    spawnPlayer();
}

void WorldMap_View::spawnPlayer()
{
    m_playerConfig.X = 64;
    m_playerConfig.Y = m_game->window().getSize().y - 96;
    m_playerConfig.CX = 64;
    m_playerConfig.CY = 64;
    m_playerConfig.SPEED += 5;
    m_player = m_entityManager.addEntity("player");
    m_player->addComponent<CTransform>(Vec2(m_playerConfig.X, m_playerConfig.Y));
    m_player->getComponent<CTransform>().facing = Vec2(1,0);
    m_player->addComponent<CAnimation>(m_game->assets().getAnimation("StandRight"), true);
    m_player->addComponent<CBoundingBox>(Vec2(m_playerConfig.CX, m_playerConfig.CY), true, false);
}

void WorldMap_View::update()
{
    m_entityManager.update();

    sMovement();
    sAnimation();
    sCamera();
}

void WorldMap_View::sMovement()
{
    Vec2 playerVelocity(0, 0);
    auto& pTrans = m_player->getComponent<CTransform>();
    if (m_player->getComponent<CInput>().left)
    {
        playerVelocity.x = playerVelocity.x - m_playerConfig.SPEED;
        pTrans.facing = Vec2(-1, 0);
    }
    if (m_player->getComponent<CInput>().right)
    {
        playerVelocity.x = playerVelocity.x + m_playerConfig.SPEED;
        pTrans.facing = Vec2(1, 0);
    }
    m_player->getComponent<CTransform>().velocity = playerVelocity;
    m_player->getComponent<CTransform>().pos = m_player->getComponent<CTransform>().pos + m_player->getComponent<CTransform>().velocity;
}

void WorldMap_View::sAnimation()
{
    auto& pAnim = m_player->getComponent<CAnimation>();
    auto& pTrans = m_player->getComponent<CTransform>();
    bool isRunning = pTrans.velocity != Vec2(0, 0);

    if (pTrans.facing.x == 1)
    {
        pTrans.scale.x = 1;
        if (isRunning && pAnim.animation.getName() != "RunRight")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("RunRight"), true);
        }
        else if (!isRunning && pAnim.animation.getName() != "StandRight")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("StandRight"), true);
        }
    }
    else if (pTrans.facing.x == -1)
    {
        pTrans.scale.x = -1;
        if (isRunning && pAnim.animation.getName() != "RunRight")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("RunRight"), true);
        }
        else if (!isRunning && pAnim.animation.getName() != "StandRight")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("StandRight"), true);
        }
    }

    for (auto e : m_entityManager.getEntities())
    {
        if (e->hasComponent<CAnimation>())
        {
            auto& anim = e->getComponent<CAnimation>();
            anim.animation.update();
            if (!anim.repeat && anim.animation.hasEnded())
            {
                e->destroy();
            }
        }
    }
}

void WorldMap_View::sCollision()
{
}

void WorldMap_View::sCamera()
{
    auto& pPos = m_player->getComponent<CTransform>().pos;
    float windowCenterX = std::max(m_game->window().getSize().x / 2.0f, pPos.x);
    float distanceFromStart = m_playerConfig.X - m_player->getComponent<CTransform>().pos.x;
    sf::View view = m_game->window().getView();
    view.setCenter(windowCenterX, m_game->window().getSize().y - view.getCenter().y);
    for (auto& b : m_entityManager.getEntities("bck1"))
    {
        auto& banim = b->getComponent<CAnimation>().animation.getName();
        if (banim == "Smoke")
        {
            b->getComponent<CTransform>().pos = Vec2(windowCenterX, m_game->window().getSize().y - view.getCenter().y);
        }
        if (banim == "Factory")
        {
            b->getComponent<CTransform>().pos.x = -1* distanceFromStart / 3 + 400;
        }
        if (banim == "Skyline")
        {
            b->getComponent<CTransform>().pos.x = -1 * distanceFromStart / 5 + 600;
        }
    }
}


    
void WorldMap_View::sRender()
{
    // RENDERING DONE FOR YOU

    m_game->window().clear(sf::Color(72, 50, 72));
    sf::RectangleShape tick({ 1.0f, 6.0f });
    tick.setFillColor(sf::Color::Black);

    auto& pPos = m_player->getComponent<CTransform>().pos;
    float windowCenterX = std::max(m_game->window().getSize().x / 2.0f, pPos.x);
    sf::View view = m_game->window().getView();
    view.setCenter(windowCenterX, m_game->window().getSize().y - view.getCenter().y);
    m_game->window().setView(view);

    if (m_drawTextures)
    {
        for (auto e : m_entityManager.getEntities())
        {
            auto& transform = e->getComponent<CTransform>();
            sf::Color c = sf::Color::White;
            if (e->hasComponent<CInvincibility>())
            {
                c = sf::Color(255, 255, 255, 128);
            }

            if (e->hasComponent<CAnimation>())
            {
                auto& animation = e->getComponent<CAnimation>().animation;
                animation.getSprite().setRotation(transform.angle);
                animation.getSprite().setPosition(transform.pos.x, transform.pos.y);
                animation.getSprite().setScale(transform.scale.x, transform.scale.y);
                animation.getSprite().setColor(c);
                if (e->hasComponent<CShader>())
                {
                    sf::Shader& shader = *e->getComponent<CShader>().shader;
                    m_game->window().draw(animation.getSprite(), &*e->getComponent<CShader>().shader);
                }
                else
                {
                    m_game->window().draw(animation.getSprite());
                }
            }
        }
    }
}

void WorldMap_View::sDoAction(const Action& action)
{
    auto& pInput = m_player->getComponent<CInput>();

    if (action.type() == "START")
    {
        if (action.name() == "PAUSE") { setPaused(!m_paused); }
        else if (action.name() == "QUIT") { onEnd(); }
        else if (action.name() == "LEFT") { pInput.left = true; }
        else if (action.name() == "RIGHT") { pInput.right = true; }
        else if (action.name() == "START")
        {
            auto& pTrans = m_player->getComponent<CTransform>();
            auto level1 = "level1.txt";
            auto level2 = "level2.txt";
            auto level3 = "level3.txt";
            if (pTrans.pos.x > 260 && pTrans.pos.x < 340)
            {
                m_game->changeScene("ZELDA1", std::make_shared<Scene_Zelda>(m_game, level1));
                m_game->assets().getSound("MusicTitle").stop();
            }
            else if (pTrans.pos.x > 560 && pTrans.pos.x < 640)
            {
                m_game->changeScene("ZELDA2", std::make_shared<Scene_Zelda>(m_game, level2));
                m_game->assets().getSound("MusicTitle").stop();
            }
            else if (pTrans.pos.x > 860 && pTrans.pos.x < 940)
            {
                m_game->changeScene("ZELDA3", std::make_shared<Scene_Zelda>(m_game, level3));
                m_game->assets().getSound("MusicTitle").stop();
            }
        }
    }
    else if (action.type() == "END")
    {
        if (action.name() == "LEFT") { pInput.left = false; }
        else if (action.name() == "RIGHT") { pInput.right = false; }
    }
}

void WorldMap_View::onEnd()
{
    m_game->playSound("MusicTitle");
    m_game->changeScene("MENU", nullptr, true);
}