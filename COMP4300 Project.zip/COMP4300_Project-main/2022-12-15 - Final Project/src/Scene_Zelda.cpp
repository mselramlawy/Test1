///\/\/\\\\\//////\/\/\/\\\///\\\/\/\/\\\\\//////\/\/\/\\\///\\\
//
//  Assignment       COMP4300 - Assignment 4
//  Professor:       David Churchill
//  Year / Term:     2022-09
//  File Name:       Scene_Zelda.cpp
// 
//  Student Name:    Yeong Shu Chun
//  Student User:    yschun
//  Student Email:   yschun@mun.ca
//  Student ID:      201623048
//  Group Member(s): [enter student name(s)]
//
///\/\/\\\\\//////\/\/\/\\\///\\\/\/\/\\\\\//////\/\/\/\\\///\\\
                                                                          
#include "Scene_Zelda.h"
#include "Common.h"
#include "Physics.h"
#include "Assets.h"
#include "GameEngine.h"
#include "Components.h"
#include <cmath>
#include "Settings.h"
#include "Scene_Settings.h"
#include <chrono>
#include <thread>


Scene_Zelda::Scene_Zelda(GameEngine* game, const std::string& levelPath, std::string prevScene)
    : Scene(game)
    , m_levelPath(levelPath)
    , m_prevScene(prevScene)
{
    init(m_levelPath);
}


void Scene_Zelda::init(const std::string& levelPath)
{
    loadLevel(levelPath);
    bindActions();

    // Register the actions required to play the game



    for (const auto& [key, value] : Settings::keyMap)
    {
        registerAction(key, value);
    }
}
              
void Scene_Zelda::bindActions()
{
    registerAction(sf::Keyboard::Escape, "QUIT");
    registerAction(sf::Keyboard::P, "PAUSE");
    registerAction(sf::Keyboard::Y, "TOGGLE_FOLLOW");      // Toggle drawing (T)extures
    registerAction(sf::Keyboard::T, "TOGGLE_TEXTURE");      // Toggle drawing (T)extures
    registerAction(sf::Keyboard::C, "TOGGLE_COLLISION");    // Toggle drawing (C)ollision Boxes
    registerAction(sf::Keyboard::D, "RIGHT");
    registerAction(sf::Keyboard::Num1, "ITEM1");
    registerAction(sf::Keyboard::Num2, "ITEM2");
    registerAction(sf::Keyboard::Num3, "ITEM3");
    registerAction(sf::Keyboard::Num4, "ITEM4");
    registerAction(sf::Keyboard::Z, "SWAP_WEAPON");
    registerAction(sf::Keyboard::E, "EQUIP_WEAPON");
    registerAction(sf::Keyboard::LShift, "DODGE");
    registerAction(sf::Keyboard::G, "ATTACK");
    registerAction(sf::Keyboard::Enter, "SAVE");

    for (const auto& [key, value] : Settings::keyMap)
    {
        registerAction(key, value);
    }

}

void Scene_Zelda::loadLevel(const std::string& filename)
{
    m_entityManager = EntityManager();

    // Load the level file and put all entities in the manager
    // Use the getPosition() function below to convert room-tile coords to game world coords
    std::ifstream fin(filename);
    std::string entityName;
    while (fin >> entityName)
    {
        if (entityName == "Tile")
        {
            std::string animationName;
            int rx, ry, tx, ty, bm, bv;
            fin >> animationName >> rx >> ry >> tx >> ty >> bm >> bv;
            auto tile = m_entityManager.addEntity("tile");
            Animation animation = m_game->assets().getAnimation(animationName);
            tile->addComponent<CAnimation>(animation, true);
            tile->addComponent<CTransform>(getPosition(rx, ry, tx, ty));
            tile->addComponent<CBoundingBox>(animation.getSize(), bm, bv);
            if (animationName == "Water" || animationName == "Lava" || animationName == "Acid")
            {
                tile->addComponent<CDamage>();
                tile->getComponent<CDamage>().damage = 1;
                tile->addComponent<CLightSource>(90);
            }
        }
        else if (entityName == "NPC")
        {
            std::string animationName, aiBehaviorName, weaponName;
            int rx, ry, tx, ty, bm, bv, h, d;
            float s;
            fin >> animationName >> rx >> ry >> tx >> ty >> bm >> bv >> h >> d >> weaponName;
            std::shared_ptr<WeaponConfig> weaponConfig = loadWeaponConfig(weaponName, fin);
            auto enemy = m_entityManager.addEntity("enemy");
            auto& animation = m_game->assets().getAnimation(animationName);
            enemy->addComponent<CAnimation>(animation, true);
            enemy->addComponent<CTransform>(getPosition(rx, ry, tx, ty));
            enemy->addComponent<CBoundingBox>(animation.getSize(), bm, bv);
            enemy->addComponent<CHealth>(h, h);
            enemy->addComponent<CDamage>(d, "enemy");
            loadAIConfig(enemy, rx, ry, tx, ty, fin);
            enemy->getComponent<CTransform>().room = Vec2(rx, ry);
            enemy->getComponent<CTransform>().grid = Vec2(tx, ty);
            if (animationName != "MoveTile")
            {
                enemy->getComponent<CTransform>().pos = getPosition(0, 1, 2, 2); //put enemies in a cage till they need to be moved for combat
            }
            if (animationName == "MoveTile")
            {
                enemy->removeComponent<CHealth>();
                enemy->removeComponent<CDamage>();
                enemy->removeComponent<CWeapon>();
            }
            if (animationName == "Boss")
            {
                enemy->addComponent<CBoss>(360);
            }
            enemy->addComponent<CWeapon>(weaponConfig);

        }
        else if (entityName == "Player")
        {
            std::string weaponName;
            fin >> m_playerConfig.X >> m_playerConfig.Y >> m_playerConfig.CX >> m_playerConfig.CY >> m_playerConfig.SPEED >> m_playerConfig.HEALTH >> weaponName;
            std::shared_ptr<WeaponConfig> weaponConfig = loadWeaponConfig(weaponName, fin);
            m_playerConfig.WEAPON = weaponConfig;
        }
        else if (entityName == "DarkRoom")
        {
            int rx, ry;
            fin >> rx >> ry;
            darkRooms.insert(std::make_pair(rx, ry));
        }
        else if (entityName == "Item")
        {
            std::string animationName, itemType;
            int rx, ry, tx, ty;
            fin >> animationName >> rx >> ry >> tx >> ty >> itemType;
            auto item = m_entityManager.addEntity("item");
            Animation animation = m_game->assets().getAnimation(animationName);
            item->addComponent<CAnimation>(animation, true);
            item->addComponent<CTransform>(getPosition(rx, ry, tx, ty));
            item->addComponent<CBoundingBox>(animation.getSize(), 0, 0);
            if (itemType == "Consumable")
            {
                std::string name;
                int count;
                fin >> name >> count;
                std::shared_ptr<ItemConfig> itemConfig = std::make_shared<ItemConfig>();
                itemConfig->name = name;
                itemConfig->cooldown = 120;
                itemConfig->count = count;
                item->addComponent<CConsumable>(itemConfig);
            }
            else if (itemType == "Weapon")
            {
                std::string weaponName;
                fin >> weaponName;
                std::shared_ptr<WeaponConfig> weaponConfig = loadWeaponConfig(weaponName, fin);
                item->addComponent<CWeapon>(weaponConfig);
            }
        }
    }

    m_game->playSound("MusicPlay");
    spawnPlayer();
}

Vec2 Scene_Zelda::getPosition(int rx, int ry, int tx, int ty) const
{
    int x = rx * 1280 + tx * 64 + 32;
    int y = ry * 768 + ty * 64 + 32;

    return Vec2(x, y);
}
                                                                          
void Scene_Zelda::spawnPlayer()
{
    m_player = m_entityManager.addEntity("player");
    m_player->addComponent<CTransform>(Vec2(m_playerConfig.X, m_playerConfig.Y));
    m_player->addComponent<CAnimation>(m_game->assets().getAnimation("StandDown"), true);
    m_player->addComponent<CBoundingBox>(Vec2(m_playerConfig.CX, m_playerConfig.CY), true, false);
    m_player->addComponent<CHealth>(m_playerConfig.HEALTH, m_playerConfig.HEALTH);
    m_player->addComponent<CWeapon>(m_playerConfig.WEAPON);
    m_player->addComponent<CLightSource>(500);
    m_player->addComponent<CInventory>();
}

void Scene_Zelda::spawnSword(std::shared_ptr<Entity> entity, int damage, int lifespan)
{
    auto sword = m_entityManager.addEntity("sword");
    sword->addComponent<CDamage>(damage, entity->id() == m_player->id() ? "player" : "enemy");
    sword->addComponent<CLifeSpan>(lifespan, m_currentFrame);
    sword->addComponent<CAttachedTo>(entity);

    if (entity == m_player)
    {
        m_game->playSound("Slash");
    }
}

void Scene_Zelda::spawnBullet(std::shared_ptr<Entity> entity, float theta, int speed, int homingRadius, int damage, int lifespan)
{
    auto& eTrans = entity->getComponent<CTransform>();
    auto bullet = m_entityManager.addEntity("bullet");

    std::string bulletAnimationName = homingRadius > 0 ? "HomingBullet" : "Bullet";
    Animation animation = m_game->assets().getAnimation(bulletAnimationName);
    bullet->addComponent<CTransform>(Vec2(eTrans.pos.x, eTrans.pos.y), Vec2(speed * cos(theta), speed * sin(theta)), Vec2(1, 1), 0);
    bullet->addComponent<CAnimation>(animation, true);
    bullet->addComponent<CBoundingBox>(animation.getSize());
    bullet->addComponent<CLifeSpan>(lifespan, m_currentFrame);
    bool playerSpawned = entity->id() == m_player->id();
    bullet->addComponent<CDamage>(damage, playerSpawned ? "player" : "enemy");
    bullet->addComponent<CHoming>(homingRadius, playerSpawned ? "enemy" : "player");
    if (!playerSpawned)
    {
        std::shared_ptr<sf::Shader> shader = getShader("EnemyBullet", "shaders/bullet.frag");
        bullet->addComponent<CShader>(shader);
        shader->setUniform("texture", sf::Shader::CurrentTexture);
        shader->setUniform("bulletColor", sf::Vector3f(1, 0, 0));
    }
    if (homingRadius > 0)
    {
        bullet->addComponent<CRotate>();
    }
    m_game->playSound("Slash");
}

void Scene_Zelda::spawnLaser(std::shared_ptr<Entity> entity, int damage, int lifespan)
{
    auto& eTrans = entity->getComponent<CTransform>();

    auto laser = m_entityManager.addEntity("laser");
    laser->addComponent<CLifeSpan>(lifespan, m_currentFrame);
    laser->addComponent<CDamage>(damage, entity == m_player ? "player" : "enemy");
    laser->addComponent<CAttachedTo>(entity);
    updateLaserAnimation(laser);
}

std::shared_ptr<Entity> Scene_Zelda::spawnProjectile(std::shared_ptr<Entity> entity, std::string animationName, float theta, int speed, int homingRadius, int damage, int lifespan, std::shared_ptr<sf::Shader> shader)
{
    auto& eTrans = entity->getComponent<CTransform>();
    auto projectile = m_entityManager.addEntity("bullet");

    Animation animation = m_game->assets().getAnimation(animationName);
    projectile->addComponent<CTransform>(Vec2(eTrans.pos.x, eTrans.pos.y), Vec2(speed * cos(theta), speed * sin(theta)), Vec2(1, 1), 0);
    projectile->addComponent<CAnimation>(animation, true);
    projectile->addComponent<CBoundingBox>(animation.getSize());
    projectile->addComponent<CLifeSpan>(lifespan, m_currentFrame);
    bool playerSpawned = entity == m_player;
    projectile->addComponent<CDamage>(damage, playerSpawned ? "player" : "enemy");
    projectile->addComponent<CHoming>(homingRadius, playerSpawned ? "enemy" : "player");
    if (shader != nullptr)
    {
        projectile->addComponent<CShader>(shader);
    }
    if (homingRadius > 0)
    {
        projectile->addComponent<CRotate>();
    }
    return projectile;
}

void Scene_Zelda::spawnBombExplosion(std::shared_ptr<Entity> entity)
{
    auto& explosion = m_entityManager.addEntity("explosion");
    auto& animation = m_game->assets().getAnimation("BombExplosion");
    explosion->addComponent<CTransform>(entity->getComponent<CTransform>().pos);
    explosion->addComponent<CAnimation>(animation, false);
    explosion->addComponent<CBoundingBox>(animation.getSize());
    explosion->addComponent<CDamage>(5, entity->getComponent<CExplosion>().dmgSource);
    explosion->addComponent<CIgnoreBlockMovment>();
}

void Scene_Zelda::spawnPoisonPool(std::shared_ptr<Entity> entity)
{
    auto& pool = m_entityManager.addEntity("poisonpool");
    auto& animation = m_game->assets().getAnimation("PoisonPool");
    pool->addComponent<CTransform>(entity->getComponent<CTransform>().pos);
    pool->addComponent<CAnimation>(animation, true);
    pool->addComponent<CLifeSpan>(30, m_currentFrame);
    pool->addComponent<CBoundingBox>(animation.getSize());
    pool->addComponent<CDamage>(0, entity->getComponent<CExplosion>().dmgSource);
    pool->addComponent<CIgnoreBlockMovment>();
    auto shader = getShader("poisonpool", "shaders/poison_pool.frag");
    shader->setUniform("texture", sf::Shader::CurrentTexture);
    pool->addComponent<CShader>(shader);
    std::vector<std::string> statuses = { "poison" };
    pool->addComponent<CStatusEffects>(statuses);
}

void Scene_Zelda::attack(std::shared_ptr<Entity> entity)
{
    auto& pTrans = m_player->getComponent<CTransform>();
    auto& eTrans = entity->getComponent<CTransform>();
    auto& eWeapon = entity->getComponent<CWeapon>();
    std::string weaponName = eWeapon.config->name;

    if (weaponName == "gun")
    {
        if (entity->id() == m_player->id())
        {
            spawnBullet(m_player, atan2f(pTrans.facing.y, pTrans.facing.x), eWeapon.config->bulletSpeed, eWeapon.config->homingRadius, eWeapon.config->damage, eWeapon.config->lifespan);
        }
        else
        {
            Vec2 diff = pTrans.pos - eTrans.pos;
            spawnBullet(entity, atan2f(diff.y, diff.x), eWeapon.config->bulletSpeed, eWeapon.config->homingRadius, eWeapon.config->damage, eWeapon.config->lifespan);
        }
    }
    else if (weaponName == "spreadgun")
    {
        // spawn 4 bullets in the cardinal directions
        for (int i = 0; i < 4; i++)
        {
            spawnBullet(entity, i*3.1415/2, eWeapon.config->bulletSpeed, eWeapon.config->homingRadius, eWeapon.config->damage, eWeapon.config->lifespan);
        }
    }
    else if (weaponName == "shotgun")
    {
        float thetaInitial;
        if (entity->id() == m_player->id())
        {
            thetaInitial = atan2f(pTrans.facing.y, pTrans.facing.x);
        }
        else
        {
            Vec2 diff = pTrans.pos - eTrans.pos;
            thetaInitial = atan2f(diff.y, diff.x);
        }
        spawnBullet(entity, thetaInitial, eWeapon.config->bulletSpeed, eWeapon.config->homingRadius, eWeapon.config->damage, eWeapon.config->lifespan);
        // fires additional bullets 15 and 30 degrees away
        float offsets[] = { 0.261799 , 0.523598 };
        for (float offset : offsets)
        {
            spawnBullet(entity, thetaInitial + offset, eWeapon.config->bulletSpeed, eWeapon.config->homingRadius, eWeapon.config->damage, eWeapon.config->lifespan);
            spawnBullet(entity, thetaInitial - offset, eWeapon.config->bulletSpeed, eWeapon.config->homingRadius, eWeapon.config->damage, eWeapon.config->lifespan);
        }
    }
    else if (weaponName == "laser")
    {
        spawnLaser(entity, eWeapon.config->damage, eWeapon.config->lifespan);
    }
    else if (weaponName == "sword")
    {
        spawnSword(entity, eWeapon.config->damage, eWeapon.config->lifespan);
    }
}

void Scene_Zelda::useItem(std::shared_ptr<ItemConfig> item)
{
    auto& pHealth = m_player->getComponent<CHealth>();
    auto& pTrans = m_player->getComponent<CTransform>();
    if (item->name == "health")
    {
        pHealth.current += std::min(pHealth.max / 2, pHealth.max - pHealth.current);
    }
    else if (item->name == "speed")
    {
        m_player->addComponent<CSpeedUp>(360);
    }
    else if (item->name == "bomb")
    {
        auto bomb = spawnProjectile(m_player, "Bomb", atan2f(pTrans.facing.y, pTrans.facing.x), 7, 0, 0, 90, nullptr);
        bomb->addComponent<CExplosion>("player", &Scene_Zelda::spawnBombExplosion);
    }
    else if (item->name == "poison")
    {
        auto poison = spawnProjectile(m_player, "Poison", atan2f(pTrans.facing.y, pTrans.facing.x), 7, 0, 0, 90, nullptr);
        poison->addComponent<CExplosion>("player", &Scene_Zelda::spawnPoisonPool);
    }
}

void Scene_Zelda::dodge(std::shared_ptr<Entity> entity)
{
    auto& eTrans = entity->getComponent<CTransform>();
    auto dodge = m_entityManager.addEntity("dodge");

    if (eTrans.facing == Vec2(-1, 0))
    {
        eTrans.velocity.x = -m_playerConfig.SPEED * 1.25;
    }
    else if (eTrans.facing == Vec2(1, 0))
    {
        eTrans.velocity.x = m_playerConfig.SPEED * 1.25;
    }

    else if (eTrans.facing == Vec2(0, 1))
    {
        eTrans.velocity.y = m_playerConfig.SPEED * 1.25;
    }
    else if (eTrans.facing == Vec2(0, -1))
    {
        eTrans.velocity.y = -m_playerConfig.SPEED * 1.25;
    }
    dodge->addComponent<CLifeSpan>(20, m_currentFrame);
    m_player->addComponent<CInvincibility>(20);
}

void Scene_Zelda::fall(std::shared_ptr<Entity> entity)
{
    auto fall = m_entityManager.addEntity("fall");
    fall->addComponent<CLifeSpan>(20, m_currentFrame);
    Vec2 pPos = m_player->getComponent<CTransform>().pos;
    Vec2 room = GetRoom(pPos);
    int x = room.x * 1280 + 640;
    int y = room.y * 768 + 384;
    pPos = Vec2(x, y);
    fall->addComponent<CLifeSpan>(20, m_currentFrame);
}

void Scene_Zelda::update()
{
    m_entityManager.update();

    if (!m_paused)
    {
        sInventory();
        sAI();
        sMovement();
        sStatus();
        checkCombat();
        sCollision();
        BossCombat();
        sAnimation();
        m_currentFrame++;
    }
    sCamera();
}

void Scene_Zelda::sMovement()
{
    auto& pInput = m_player->getComponent<CInput>();
    auto& pTrans = m_player->getComponent<CTransform>();
    auto& pWeapon = m_player->getComponent<CWeapon>();
    bool inDodge = m_entityManager.getEntities("dodge").size() == 1;
    bool inFall = m_entityManager.getEntities("fall").size() == 1;

    if (!inDodge)
    {
        pTrans.velocity = Vec2(0, 0);
    }

    if (pInput.left && !pInput.right && !pInput.up && !pInput.down && !pInput.dodge && !inDodge && !inFall)
    {
        pTrans.velocity.x = -m_playerConfig.SPEED;
        pTrans.facing = Vec2(-1, 0);
    }
    else if (pInput.right && !pInput.left && !pInput.up && !pInput.down && !pInput.dodge && !inDodge && !inFall)
    {
        pTrans.velocity.x = m_playerConfig.SPEED;
        pTrans.facing = Vec2(1, 0);
    }
    else if (pInput.up && !pInput.left && !pInput.right && !pInput.down && !pInput.dodge && !inDodge && !inFall)
    {
        pTrans.velocity.y = -m_playerConfig.SPEED;
        pTrans.facing = Vec2(0, -1);
    }
    else if (pInput.down && !pInput.left && !pInput.right && !pInput.up && !pInput.dodge && !inDodge && !inFall)
    {
        pTrans.velocity.y = m_playerConfig.SPEED;
        pTrans.facing = Vec2(0, 1);
    }

    if (pInput.attack && pWeapon.canAttack(m_currentFrame) && !pInput.dodge && !inDodge && !inFall)
    {
        pWeapon.lastFired = m_currentFrame;
        attack(m_player);
    }

    if (pInput.dodge && !pInput.attack && !inDodge && !inFall)
    {
        dodge(m_player);
    }
    if (inFall && !inDodge)
    {
        pTrans.velocity = Vec2(0, 0);
        fall(m_player);
    }
    for (auto& e : m_entityManager.getEntities())
    {
        auto& eTrans = e->getComponent<CTransform>();
        if (e->hasComponent<CTransform>())
        {
            if (e->hasComponent<CSpeedUp>() && !inDodge)
            {
                eTrans.velocity *= 2;
            }
            eTrans.prevPos = eTrans.pos;
            eTrans.pos += eTrans.velocity;
            if (e->id() != m_player->id())
            {
                // NPC face whichever direction has the highest velocity component
                if (eTrans.velocity == Vec2(0, 0))
                {
                    eTrans.facing = Vec2(0, 1);
                }
                else
                {
                    eTrans.facing = abs(eTrans.velocity.x) > abs(eTrans.velocity.y) ? Vec2(eTrans.velocity.x, 0) / abs(eTrans.velocity.x)
                        : Vec2(0, eTrans.velocity.y) / abs(eTrans.velocity.y);
                }
            }
            if (e->hasComponent<CRotate>())
            {
                eTrans.angle = atan2f(eTrans.velocity.y, eTrans.velocity.x) * 180 / 3.1415;
            }
        }
        if (e->hasComponent<CHoming>())
        {
            for (auto& e2 : m_entityManager.getEntities(e->getComponent<CHoming>().targetTag))
            {
                auto& e2Trans = e2->getComponent<CTransform>();
                bool isMoveTile = e2->getComponent<CAnimation>().animation.getName() == "MoveTile"; //prevent homing toward tile
                if (eTrans.pos.dist(e2Trans.pos) < e->getComponent<CHoming>().radius && !isMoveTile)
                {
                    float currSpeed = eTrans.velocity.dist(Vec2(0, 0));
                    Vec2 diff = e2Trans.pos - eTrans.pos;
                    Vec2 desired = diff / diff.dist(Vec2(0, 0)) * currSpeed;
                    Vec2 steering = (desired - eTrans.velocity) * 0.3;
                    Vec2 adjusted = eTrans.velocity + steering;
                    // make the speed the same as it was previously
                    eTrans.velocity = adjusted / adjusted.dist(Vec2(0, 0)) * currSpeed;
                    break;
                }
            }
        }
    }
}

void Scene_Zelda::sDoAction(const Action& action)
{                        
    auto& pInput = m_player->getComponent<CInput>();

    if (action.type() == "START")
    {
        
             if (action.name() == "PAUSE") { setPaused(!m_paused); }
        else if (action.name() == "QUIT") { onEnd(); }
        else if (action.name() == "TOGGLE_FOLLOW") { m_follow = !m_follow; }
        else if (action.name() == "TOGGLE_TEXTURE") { m_drawTextures = !m_drawTextures; }
        else if (action.name() == "TOGGLE_COLLISION") { m_drawCollision = !m_drawCollision; }
        else if (action.name() == "UP") { pInput.up = true; }
        else if (action.name() == "DOWN") { pInput.down = true; }
        else if (action.name() == "LEFT") { pInput.left = true; }
        else if (action.name() == "RIGHT") { pInput.right = true; }
        else if (action.name() == "ATTACK") { pInput.attack = true; }
        else if (action.name() == "DODGE") { pInput.dodge = true; }
        else if (action.name() == "ITEM1") { pInput.items[0] = true; }
        else if (action.name() == "ITEM2") { pInput.items[1] = true; }
        else if (action.name() == "ITEM3") { pInput.items[2] = true; }
        else if (action.name() == "ITEM4") { pInput.items[3] = true; }
        else if (action.name() == "SWAP_WEAPON") { pInput.swapWeapon = true; }
        else if (action.name() == "EQUIP_WEAPON") { pInput.equip = true; }
        else if (action.name() == "SAVE") { saveLevel(); }
    }
    else if (action.type() == "END")
    {
             if (action.name() == "UP") { pInput.up = false; }
        else if (action.name() == "DOWN") { pInput.down = false; }
        else if (action.name() == "LEFT") { pInput.left = false; }
        else if (action.name() == "RIGHT") { pInput.right = false; }
        else if (action.name() == "ATTACK") { pInput.attack = false; }
        else if (action.name() == "DODGE") { pInput.dodge = false; }
        else if (action.name() == "ITEM1") { pInput.items[0] = false; }
        else if (action.name() == "ITEM2") { pInput.items[1] = false; }
        else if (action.name() == "ITEM3") { pInput.items[2] = false; }
        else if (action.name() == "ITEM4") { pInput.items[3] = false; }
        else if (action.name() == "SWAP_WEAPON") { pInput.swapWeapon = false; }
        else if (action.name() == "EQUIP_WEAPON") { pInput.equip = false; }
    }
    
}

void Scene_Zelda::sAI()
{
    auto& pTrans = m_player->getComponent<CTransform>();
    for (auto& e : m_entityManager.getEntities("enemy"))
    {
        auto& eTrans = e->getComponent<CTransform>();
        float speed = 0;
        if (e->hasComponent<CFollowPlayer>())
        {
            auto& eFollow = e->getComponent<CFollowPlayer>();
            speed = eFollow.speed;;
            bool inPlayersRoom = Vec2(floor(eTrans.pos.x / 1280), floor(eTrans.pos.y / 768)) == Vec2(floor(pTrans.pos.x / 1280), floor(pTrans.pos.y / 768));
            bool visionBlocked = false;
            if (!inPlayersRoom)
            {
                // enemies cannot see the player in another room
                visionBlocked = true;
            }
            else
            {
                for (auto& e2 : m_entityManager.getEntities())
                {
                    if (e2->hasComponent<CBoundingBox>() && e2->getComponent<CBoundingBox>().blockVision && Physics::EntityIntersect(eTrans.pos, pTrans.pos, e2))
                    {
                        visionBlocked = true;
                        break;
                    }
                }
            }
            if (!visionBlocked)
            {
                Vec2 diff = pTrans.pos - eTrans.pos;
                eTrans.velocity = diff;
            }
            else if (m_currentFrame % 60 == 0)
            {
                int randTheta = (rand() % 360) * 3.1415 / 180;
                eTrans.velocity = Vec2(cos(randTheta), sin(randTheta));
            }
        }
        else if (e->hasComponent<CPatrol>())
        {
            auto& ePatrol = e->getComponent<CPatrol>();
            speed = ePatrol.speed;
            if (eTrans.pos.dist(ePatrol.positions[ePatrol.currentPosition]) < 5)
            {
                ePatrol.currentPosition = (ePatrol.currentPosition + 1) % ePatrol.positions.size();
            }
            Vec2 diff = ePatrol.positions[ePatrol.currentPosition] - eTrans.pos;
            eTrans.velocity = diff;
        }
        else if (e->hasComponent<CKeepDistance>())
        {
            auto& eKeepDist = e->getComponent<CKeepDistance>();
            speed = eKeepDist.speed;
            if (eTrans.pos.dist(pTrans.pos) < eKeepDist.range)
            {
                Vec2 diff = eTrans.pos - pTrans.pos;
                eTrans.velocity = diff;
            }
            else
            {
                eTrans.velocity = Vec2(0, 0);
            }
        }
        if (e->hasComponent<CEnraged>())
        {
            auto& eEnraged = e->getComponent<CEnraged>();
            if (e->getComponent<CHealth>().current <= eEnraged.threshold && !eEnraged.isEnraged)
            {
                eEnraged.isEnraged = true;
                speed *= eEnraged.speedScale;
                e->getComponent<CDamage>().damage *= eEnraged.dmgScale;
                if (e->hasComponent<CWeapon>())
                {
                    e->getComponent<CWeapon>().config->cooldown /= eEnraged.speedScale;
                    e->getComponent<CWeapon>().config->damage *= eEnraged.dmgScale;
                }
                std::shared_ptr<sf::Shader> shader = getShader("EnemyEnraged", "shaders/enraged.frag");
                e->addComponent<CShader>(shader);
                shader->setUniform("texture", sf::Shader::CurrentTexture);
                shader->setUniform("time", time.getElapsedTime().asSeconds());
            }
            else if (eEnraged.isEnraged)
            {
                e->getComponent<CShader>().shader->setUniform("time", time.getElapsedTime().asSeconds());
                speed *= eEnraged.speedScale;
            }
        }
        if (eTrans.velocity != Vec2(0, 0))
        {
            eTrans.velocity = eTrans.velocity / eTrans.velocity.dist(Vec2(0, 0)) * speed;
        }

        if (e->hasComponent<CWeapon>() && e->getComponent<CWeapon>().canAttack(m_currentFrame))
        {
            auto& eWeapon = e->getComponent<CWeapon>();
            eWeapon.lastFired = m_currentFrame;
            attack(e);
        }
    }
}

Vec2 Scene_Zelda::GetRoom(Vec2 pos)
{
    int rx = floor(pos.x / 1280);
    int ry = floor(pos.y / 768);
    int x = rx;
    int y = ry;
    return Vec2(x, y);
}

void Scene_Zelda::startCombat()
{
    doorLock(true);
    //teleport enemies to room
    Vec2 pPos = m_player->getComponent<CTransform>().pos;
    Vec2 pRoom = GetRoom(pPos);
    for (auto& e : m_entityManager.getEntities("enemy"))
    {
        if (e->hasComponent<CDamage>())
        { 
            auto& etrans = e->getComponent<CTransform>();
            if (etrans.room == pRoom)
            {
                e->addComponent<CTransform>(getPosition(etrans.room.x, etrans.room.y, etrans.grid.x, etrans.grid.y));
            }
        }
    }

}

void Scene_Zelda::checkCombat()
{
    Vec2 pRoom = GetRoom(m_player->getComponent<CTransform>().pos);
    bool alone = true;
    for (auto& e : m_entityManager.getEntities("enemy"))
    {
        if (e->hasComponent<CDamage>())
        {
            Vec2 eRoom = GetRoom(e->getComponent<CTransform>().pos);
            if (eRoom == pRoom)
            {
                alone = false;
            }
        }

    }
    doorLock(!alone);
    m_follow = alone;
}

void Scene_Zelda::BossCombat()
{
    for (auto& b : m_entityManager.getEntities("enemy"))
    {
        if (b->hasComponent<CBoss>())
        {

            if (m_currentFrame > b->getComponent<CBoss>().phaseStart + b->getComponent<CBoss>().phaseLength)
            {
                if (b->getComponent<CBoss>().phase == 3)
                {
                    b->getComponent<CBoss>().phase = 1;
                    b->getComponent<CBoss>().phaseStart = m_currentFrame;
                }
                else
                {
                    b->getComponent<CBoss>().phase++;
                    b->getComponent<CBoss>().phaseStart = m_currentFrame;
                }
            }
            auto res = b->getComponent<CWeapon>().config->cooldown;
            if (b->getComponent<CBoss>().phase == 1)
            {
                if (b->getComponent<CWeapon>().config->name != "gun")
                {
                    b->removeComponent<CFollowPlayer>();
                    std::shared_ptr<WeaponConfig> config = std::make_shared<WeaponConfig>();
                    b->addComponent<CWeapon>(config);
                    config->name = "gun";
                    config->damage = 1;
                    config->cooldown = 120;
                    config->bulletSpeed = 12;
                    config->lifespan = 120;
                    std::vector<Vec2>pos;
                    pos.push_back(Vec2(getPosition(0, -2, 11, 0)));
                    pos.push_back(Vec2(getPosition(0, -2, 11, 11)));
                    b->addComponent<CPatrol>(pos, 5);
                }
            }
            if (b->getComponent<CBoss>().phase == 3)
            {
                if (b->getComponent<CWeapon>().config->name != "shotgun")
                {
                    b->removeComponent<CFollowPlayer>();
                    std::shared_ptr<WeaponConfig> config = std::make_shared<WeaponConfig>();
                    b->addComponent<CWeapon>(config);
                    config->name = "shotgun";
                    config->damage = 1;
                    config->cooldown = 120;
                    config->bulletSpeed = 12;
                    config->lifespan = 120;
                    std::vector<Vec2>pos;
                    pos.push_back(Vec2(getPosition(0, -2, 0, 0)));
                    pos.push_back(Vec2(getPosition(0, -2, 11, 11)));
                    b->addComponent<CPatrol>(pos, 5);
                }
            }
            if (b->getComponent<CBoss>().phase == 2)
            {
                {
                    std::shared_ptr<WeaponConfig> config = std::make_shared<WeaponConfig>();
                    b->addComponent<CWeapon>(config);
                    b->addComponent<CFollowPlayer>(getPosition(0, -2, 5, 11), 3);
                }
            }
        }
    }
}

void Scene_Zelda::doorLock(bool status)
{
    for (auto& e : m_entityManager.getEntities("tile"))
    {
        auto aniName = e->getComponent<CAnimation>().animation.getName();
        if (aniName.rfind("Enter", 0) == 0) //if animation name starts with enter
        {
            e->getComponent<CBoundingBox>().blockMove = status;
        }
    }
}

void Scene_Zelda::sStatus()
{
    for (auto e : m_entityManager.getEntities())
    {
        if (e->hasComponent<CLifeSpan>())
        {
            if (m_currentFrame > e->getComponent<CLifeSpan>().frameCreated + e->getComponent<CLifeSpan>().lifespan)
            {
                if (e->hasComponent<CExplosion>())
                {
                    auto f = e->getComponent<CExplosion>().explodeFunc;
                    (this->*f)(e);
                }
                e->destroy();
            }
        }
        if (e->hasComponent<CInvincibility>())
        {
            if (--e->getComponent<CInvincibility>().iframes == 0)
            {
                e->removeComponent<CInvincibility>();
            }
        }
        if (e->hasComponent<CSpeedUp>())
        {
            if (--e->getComponent<CSpeedUp>().duration == 0)
            {
                e->removeComponent<CSpeedUp>();
            }
        }
        if (e->hasComponent<CPoisoned>())
        {
            auto& shader = getShader("poisoned", "shaders/poisoned.frag");
            shader->setUniform("texture", sf::Shader::CurrentTexture);
            e->addComponent<CShader>(shader);
            if (m_currentFrame % 120 == 0)
            {
                e->getComponent<CHealth>().current -= 3;
                if (e->getComponent<CHealth>().current <= 0)
                {
                    if (e == m_player)
                    {
                        m_game->playSound("LinkDie");
                        m_player->destroy();
                        spawnPlayer();
                    }
                    else
                    {
                        destroyEnemy(e);
                    }
                }
            }
            if (--e->getComponent<CPoisoned>().duration == 0)
            {
                e->removeComponent<CPoisoned>();
            }
        }
    }
}

void Scene_Zelda::sInventory()
{
    auto& pInput = m_player->getComponent<CInput>();
    auto& pInv = m_player->getComponent<CInventory>();

    for (int i = 0; i < 4; i++)
    {
        if (!pInput.items[i] || pInv.items[i] == nullptr)
        {
            continue;
        }

        auto& item = pInv.items[i];
        bool canUse = pInv.itemsLastUsed[i] == 0 || m_currentFrame > item->cooldown + pInv.itemsLastUsed[i];
        if (canUse)
        {
            useItem(item);
            if (--item->count == 0)
            {
                pInv.items[i] = nullptr;
                pInv.itemsLastUsed[i] = 0;
            }
            else
            {
                pInv.itemsLastUsed[i] = m_currentFrame;
            }
        }
    }

    if (pInput.swapWeapon)
    {
        if (pInv.secondWeapon != nullptr)
        {
            std::swap(m_player->getComponent<CWeapon>().config, pInv.secondWeapon);
            std::swap(m_player->getComponent<CWeapon>().lastFired, pInv.secondWeaponLastFired);
        }
        pInput.swapWeapon = false;
    }
}

void Scene_Zelda::sCollision()
{
    auto& pTrans = m_player->getComponent<CTransform>();
    auto& pInv = m_player->getComponent<CInventory>();

    for (auto& t : m_entityManager.getEntities("tile"))
    {
        for (auto& e : m_entityManager.getEntities())
        {
            if (e->tag() != "tile" && t->id() != e->id() && e->hasComponent<CBoundingBox>())
            {
                // entity tile collision
                auto& tTrans = t->getComponent<CTransform>();
                auto& eTrans = e->getComponent<CTransform>();
                Vec2 overlap = Physics::GetOverlap(t, e);
                if (overlap.x > 0 && overlap.y > 0)
                {
                    if (t->getComponent<CBoundingBox>().blockMove)
                    {
                        if (!e->hasComponent<CIgnoreBlockMovment>())
                        {
                            Vec2 prevOverlap = Physics::GetPreviousOverlap(t, e);
                            if (prevOverlap.x > 0)
                            {
                                bool isBelow = eTrans.pos.y > tTrans.pos.y;
                                eTrans.pos.y = eTrans.pos.y + (isBelow ? overlap.y : -overlap.y);
                            }
                            else if (prevOverlap.y > 0)
                            {
                                bool isOnRight = eTrans.pos.x > tTrans.pos.x;
                                eTrans.pos.x = eTrans.pos.x + (isOnRight ? overlap.x : -overlap.x);
                            }
                        }
                        if (e->tag() == "bullet")
                        {
                            e->destroy();
                        }
                        if (e->hasComponent<CExplosion>())
                        {
                            auto f = e->getComponent<CExplosion>().explodeFunc;
                            (this->*f)(e);
                            e->destroy();
                        }
                    }
                    else if (t->getComponent<CAnimation>().animation.getName() == "Heart" && e->hasComponent<CHealth>())
                    {
                        // entity heart collision
                        m_game->playSound("GetItem");
                        e->getComponent<CHealth>().current = e->getComponent<CHealth>().max;
                        t->destroy();
                    }
                }
            }
        }

        if (t->getComponent<CAnimation>().animation.getName() == "Black")
        {
            // black tile teleport
            Vec2 pOverlap = Physics::GetOverlap(t, m_player);
            // teleports if player is half way in the black tile
            if (pOverlap.x > 32 && pOverlap.y > 32)
            {
                EntityVec blackTiles;
                for (auto& t2 : m_entityManager.getEntities("tile"))
                {
                    if (t2->getComponent<CAnimation>().animation.getName() == "Black")
                    {
                        blackTiles.push_back(t2);
                    }
                }
                auto& newTile = blackTiles[rand() % blackTiles.size()];
                pTrans.pos = newTile->getComponent<CTransform>().pos + Vec2(0, 64);
            }
        }

        if (t->getComponent<CAnimation>().animation.getName() == "Spawner")
        {

            Vec2 pOverlap = Physics::GetOverlap(t, m_player);

            if (pOverlap.x > 32 && pOverlap.y > 32)
            {
                startCombat();
                t->destroy();
            }
        }
    }

    // item pickup
    for (auto& e : m_entityManager.getEntities("item"))
    {
        auto& eTrans = e->getComponent<CTransform>();
        Vec2 overlap = Physics::GetOverlap(e, m_player);
        if (overlap.x > 0 && overlap.y > 0)
        {
            if (e->hasComponent<CConsumable>())
            {
                auto& itemConfig = e->getComponent<CConsumable>().itemConfig;
                bool hasSameItem = false;
                int freeSlot = -1;
                for (int i = 0; i < 4; i++)
                {
                    auto& item = pInv.items[i];
                    if (item != nullptr && item->name == itemConfig->name && item->cooldown == itemConfig->cooldown)
                    {
                        item->count += itemConfig->count;
                        e->destroy();
                        hasSameItem = true;
                        break;
                    }
                    else if (item == nullptr && freeSlot == -1)
                    {
                        freeSlot = i;
                    }
                }

                if (!hasSameItem && freeSlot != -1)
                {
                    pInv.items[freeSlot] = itemConfig;
                    e->destroy();
                }
            }
            if (e->hasComponent<CWeapon>())
            {
                auto& eWeapon = e->getComponent<CWeapon>();
                if (pInv.secondWeapon == nullptr)
                {
                    pInv.secondWeapon = eWeapon.config;
                    e->destroy();
                }
                else if (m_player->getComponent<CInput>().equip)
                {
                    std::swap(m_player->getComponent<CWeapon>().config, eWeapon.config);
                    std::swap(m_player->getComponent<CWeapon>().lastFired, eWeapon.lastFired);
                    e->addComponent<CAnimation>(m_game->assets().getAnimation(getWeaponAnimation(eWeapon.config)), true);
                    m_player->getComponent<CInput>().equip = false;
                }
            }
        }
    }

    // entity entity collisions
    for (auto e : m_entityManager.getEntities())
    {
        for (auto& e2: m_entityManager.getEntities())
        {
            bool isMoveTile = e->getComponent<CAnimation>().animation.getName() == "MoveTile";
            if (isMoveTile && e2->id() == m_player->id())
            {
                // player moving tile collision
                Vec2 overlap = Physics::GetOverlap(e, m_player);
                if (overlap.x > 0 && overlap.y > 0)
                {
                    Vec2 eVelocity = e->getComponent<CTransform>().velocity;
                    pTrans.pos += eVelocity;
                    m_player->addComponent<CInvincibility>(60);
                }
            }

            // damage calculations
            bool alreadyDamaged = e2->getComponent<CDamage>().entitiesDamaged.find(e->id()) != e2->getComponent<CDamage>().entitiesDamaged.end();
            bool cannotBeDamaged = !e->isActive() || !e2->isActive() || e->id() == e2->id() || isMoveTile ||
                                    !e2->hasComponent<CDamage>() || e2->getComponent<CDamage>().dmgSource == e->tag() || !e->hasComponent<CHealth>() || e->hasComponent<CInvincibility>();
            if (alreadyDamaged || cannotBeDamaged)
            {
                continue;
            }

            Vec2 sOverlap = Physics::GetOverlap(e, e2);
            if (sOverlap.x > 0 && sOverlap.y > 0)
            {
                e->getComponent<CHealth>().current -= e2->getComponent<CDamage>().damage * (3 - (int)Settings::difficulty);
                if (e2->hasComponent<CStatusEffects>())
                {
                    applyStatuses(e2->getComponent<CStatusEffects>().statuses, e);
                }

                if (e == m_player)
                {
                    m_game->playSound("LinkHurt");
                    if (m_player->getComponent<CHealth>().current <= 0)
                    {
                        m_game->playSound("LinkDie");
                        m_player->destroy();
                        onGameOver();
                        spawnPlayer();
                    }
                    else
                    {
                        m_player->addComponent<CInvincibility>(30);
                    }
                }
                else
                {
                    m_game->playSound("EnemyHit");
                    if (e->getComponent<CHealth>().current <= 0) 
                    {
                        destroyEnemy(e);
                    }
                }
                if (e2->tag() == "bullet")
                {
                    e2->destroy();
                }
                else if (e2->tag() == "sword" || e2->tag() == "laser" || e2->tag() == "explosion")
                {
                    e2->getComponent<CDamage>().entitiesDamaged.insert(e->id());

                }
                if (e2->hasComponent<CExplosion>())
                {
                    auto f = e2->getComponent<CExplosion>().explodeFunc;
                    (this->*f)(e2);
                    e2->destroy();
                }
            }
        }
    }
}

void Scene_Zelda::sAnimation()
{
    auto& pTrans = m_player->getComponent<CTransform>();
    auto& pAnim = m_player->getComponent<CAnimation>();
    bool inDodge = m_entityManager.getEntities("dodge").size() == 1;

    bool isRunning = pTrans.velocity != Vec2(0, 0) && !inDodge;
    pTrans.scale = Vec2(1, 1);

    if (pTrans.facing == Vec2(-1, 0))
    {
        pTrans.scale.x = -1;

        if (isRunning && pAnim.animation.getName() != "RunRight")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("RunRight"), true);
        }
        else if (!isRunning && !inDodge && pAnim.animation.getName() != "StandRight")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("StandRight"), true);  
        }
        else if (inDodge && pAnim.animation.getName() != "DodgeR")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("DodgeR"), true);
        }
    }
    else if (pTrans.facing == Vec2(1, 0))
    {
        if (isRunning && pAnim.animation.getName() != "RunRight")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("RunRight"), true);
        }
        else if (!isRunning && !inDodge && pAnim.animation.getName() != "StandRight")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("StandRight"), true);
        }
        else if (inDodge && pAnim.animation.getName() != "DodgeR")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("DodgeR"), true);
        }
    }
    else if (pTrans.facing == Vec2(0, 1))
    {
        if (isRunning && pAnim.animation.getName() != "RunDown")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("RunDown"), true);
        }
        else if (!isRunning && !inDodge&& pAnim.animation.getName() != "StandDown")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("StandDown"), true);
        }
        else if (inDodge && pAnim.animation.getName() != "Dodge")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("Dodge"), true);
        }
    }
    else if (pTrans.facing == Vec2(0, -1))
    {
        if (isRunning && pAnim.animation.getName() != "RunUp")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("RunUp"), true);
        }
        else if (!isRunning && !inDodge)
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("StandUp"), true);
        }
        else if (inDodge && pAnim.animation.getName() != "Dodge")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("Dodge"), true);
        }
    }

    for (auto s : m_entityManager.getEntities("sword"))
    {
        updateSwordAnimation(s);
    }

    for (auto l : m_entityManager.getEntities("laser"))
    {
        updateLaserAnimation(l);
    }

    for (auto& b : m_entityManager.getEntities("enemy"))
    {
        if (b->hasComponent<CBoss>())
        {
            auto& banim = b->getComponent<CAnimation>().animation;

            if (b->getComponent<CEnraged>().isEnraged)
            {
                if (b->getComponent <CBoss>().phase == 2)
                {
                    if (banim.getName() != "BossBAtk")
                    {
                        b->addComponent<CAnimation>(m_game->assets().getAnimation("BossBAtk"), true);
                    }
                }
                else
                {
                    if (banim.getName() != "BossBig")
                    {
                        b->addComponent<CAnimation>(m_game->assets().getAnimation("BossBig"), true);
                    }
                }

            }
            else
            {
                if (b->getComponent <CBoss>().phase == 2)
                {
                    if (b->getComponent<CAnimation>().animation.getName() != "BossAtk")
                    {
                        b->addComponent<CAnimation>(m_game->assets().getAnimation("BossAtk"), true);
                    }
                }
                else
                {
                    if (b->getComponent<CAnimation>().animation.getName() != "Boss")
                    {
                        b->addComponent<CAnimation>(m_game->assets().getAnimation("Boss"), true);
                    }
                }

            }

        }
    }

    for (auto e : m_entityManager.getEntities())
    {
        if (e->hasComponent<CAnimation>())
        {
            auto& anim = e->getComponent<CAnimation>();
            anim.animation.update();
            if (!anim.repeat && anim.animation.hasEnded())
            {
                e->destroy();
            }
        }
    }
}

void Scene_Zelda::sCamera()
{
    // get the current view, which we will modify in the if-statement below
    sf::View view = m_game->window().getView();

    Vec2 pPos = m_player->getComponent<CTransform>().pos;

    if (m_follow)
    {
        // calculate view for player follow camera
        view.setCenter(pPos.x, pPos.y);
    }
    else
    {
        // calcluate view for room-based camera
        int rx = floor(pPos.x / 1280);
        int ry = floor(pPos.y / 768);
        int x = rx * 1280 + 640;
        int y = ry * 768 + 384;
        view.setCenter(x, y);
    }
                                                                          
    // then set the window view
    m_game->window().setView(view);
}

void Scene_Zelda::onEnd()
{
    if (m_prevScene == "")
    {
        m_game->assets().getSound("MusicPlay").stop();
        m_game->playSound("MusicTitle");
        m_game->changeScene("MENU", nullptr, true);
    }
    else
    {
        m_game->assets().getSound("MusicPlay").stop();
        m_game->changeScene(m_prevScene, nullptr, true);
    }
}

void Scene_Zelda::onGameOver()
{
    sf::RenderWindow window(sf::VideoMode(m_game->window().getSize().x, m_game->window().getSize().y), "GameOver");

    // Load the image
    sf::Texture texture;
    texture.loadFromFile("images/misc/GameOver.png");

    // Create the sprite
    sf::Sprite sprite;
    sprite.setTexture(texture);

    // Center the sprite on the screen
    sf::FloatRect spriteRect = sprite.getLocalBounds();
    sprite.setOrigin(spriteRect.left + spriteRect.width / 2.0f, spriteRect.top + spriteRect.height / 2.0f);
    sprite.setPosition(sf::Vector2f(window.getSize().x / 2.0f, window.getSize().y / 2.0f));

    // Main game loop
    auto startTime = std::chrono::high_resolution_clock::now();
    while (window.isOpen())
    {
        // Process events
        sf::Event event;
        while (window.pollEvent(event))
        {
            // Close the window if the user closes it or presses the escape key
            if (event.type == sf::Event::Closed || (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Escape))
            {
                window.close();
            }
        }

        // Clear the window
        window.clear(sf::Color::Black);

        // Draw the sprite
        window.draw(sprite);

        // Display the window
        window.display();

        // Sleep for 1 second
        std::this_thread::sleep_for(std::chrono::seconds(1));

        // Check if 5 seconds have elapsed
        auto endTime = std::chrono::high_resolution_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(endTime - startTime);
        if (elapsed.count() >= 5)
        {
            window.close();
        }
    }
    if (!texture.loadFromFile("images/misc/GameOver.png"))
    {
        std::cerr << "Could not load gameover image file" << std::endl;
    }
    else
    {
        std::cout << "Loaded Gameover image" << std::endl;
    }
}

void Scene_Zelda::sRender()
{
    // RENDERING DONE FOR YOU

    m_game->window().clear(sf::Color(0, 0, 0));
    sf::RectangleShape tick({ 1.0f, 6.0f });
    tick.setFillColor(sf::Color::Black);

    auto& pInv = m_player->getComponent<CInventory>();

    // draw all Entity textures / animations
    if (m_drawTextures)
    {
        for (auto e : m_entityManager.getEntities())
        {
            // set the darkness of the entity based on light strength
            float lightStrength = getLightStrength(e);
            if (!e->hasComponent<CShader>())
            {
                std::shared_ptr<sf::Shader> shader = getShader("DarkTile", "shaders/dark.frag");
                e->addComponent<CShader>(shader);
                shader->setUniform("texture", sf::Shader::CurrentTexture);
            }
            e->getComponent<CShader>().shader->setUniform("lightStrength", lightStrength);

            auto& transform = e->getComponent<CTransform>();
            sf::Color c = sf::Color::White;
            if (e->hasComponent<CInvincibility>())
            {
                c = sf::Color(255, 255, 255, 128);
            }
                                                                          
            if (e->hasComponent<CAnimation>())
            {
                auto& animation = e->getComponent<CAnimation>().animation;
                animation.getSprite().setRotation(transform.angle);
                animation.getSprite().setPosition(transform.pos.x, transform.pos.y);
                animation.getSprite().setScale(transform.scale.x, transform.scale.y);
                animation.getSprite().setColor(c);
                if (e->hasComponent<CShader>())
                {
                    sf::Shader & shader = *e->getComponent<CShader>().shader;
                    m_game->window().draw(animation.getSprite(), &*e->getComponent<CShader>().shader);
                }
                else
                {
                    m_game->window().draw(animation.getSprite());
                }
            }

            // only show health bar if the entity is sufficiently lit
            if (e->hasComponent<CHealth>() && e->getComponent<CHealth>().current > 0 && lightStrength > 0.1)
            {
                auto& h = e->getComponent<CHealth>();
                Vec2 size(64, 6);
                sf::RectangleShape rect({ size.x, size.y });
                rect.setPosition(transform.pos.x - 32, transform.pos.y - 48);
                rect.setFillColor(sf::Color(96, 96, 96));
                rect.setOutlineColor(sf::Color::Black);
                rect.setOutlineThickness(2);
                m_game->window().draw(rect);

                float ratio = (float)(h.current) / h.max;
                size.x *= ratio;
                rect.setSize({ size.x, size.y });
                rect.setFillColor(sf::Color(255, 0, 0));
                rect.setOutlineThickness(0);
                m_game->window().draw(rect);

                for (int i = 0; i < h.max; i++)
                {
                    tick.setPosition(rect.getPosition() + sf::Vector2f(i * 64 * 1 / h.max, 0));
                    m_game->window().draw(tick);
                }
            }
        }
    }

    // draw all Entity collision bounding boxes with a rectangleshape
    if (m_drawCollision)
    {
        sf::CircleShape dot(4);
        dot.setFillColor(sf::Color::Black);
        for (auto e : m_entityManager.getEntities())
        {
            if (e->hasComponent<CBoundingBox>())
            {
                auto& box = e->getComponent<CBoundingBox>();
                auto& transform = e->getComponent<CTransform>();
                sf::RectangleShape rect;
                rect.setSize(sf::Vector2f(box.size.x - 1, box.size.y - 1));
                rect.setOrigin(sf::Vector2f(box.halfSize.x, box.halfSize.y));
                rect.setPosition(transform.pos.x, transform.pos.y);
                rect.setFillColor(sf::Color(0, 0, 0, 0));

                if (box.blockMove && box.blockVision) { rect.setOutlineColor(sf::Color::Black); }
                if (box.blockMove && !box.blockVision) { rect.setOutlineColor(sf::Color::Blue); }
                if (!box.blockMove && box.blockVision) { rect.setOutlineColor(sf::Color::Red); }
                if (!box.blockMove && !box.blockVision) { rect.setOutlineColor(sf::Color::White); }
                rect.setOutlineThickness(1);
                m_game->window().draw(rect);
            }

            if (e->hasComponent<CPatrol>())
            {
                auto& patrol = e->getComponent<CPatrol>().positions;
                for (size_t p = 0; p < patrol.size(); p++)
                {
                    dot.setPosition(patrol[p].x, patrol[p].y);
                    m_game->window().draw(dot);
                }
            }

            if (e->hasComponent<CFollowPlayer>())
            {
                sf::VertexArray lines(sf::LinesStrip, 2);
                lines[0].position.x = e->getComponent<CTransform>().pos.x;
                lines[0].position.y = e->getComponent<CTransform>().pos.y;
                lines[0].color = sf::Color::Black;
                lines[1].position.x = m_player->getComponent<CTransform>().pos.x;
                lines[1].position.y = m_player->getComponent<CTransform>().pos.y;
                lines[1].color = sf::Color::Black;
                m_game->window().draw(lines);
                dot.setPosition(e->getComponent<CFollowPlayer>().home.x, e->getComponent<CFollowPlayer>().home.y);
                m_game->window().draw(dot);
            }
        }
    }

    // draw item slots and item sprites
    sf::RectangleShape itemSlot({ 64.0f, 64.0f });
    itemSlot.setOutlineColor(sf::Color::White);
    itemSlot.setOutlineThickness(2.0f);
    itemSlot.setFillColor(sf::Color(255, 255, 255, 25));
    for (int i = 0; i < 4; i++)
    {
        itemSlot.setPosition(m_game->window().getView().getCenter().x - 608 + i * 64, m_game->window().getView().getCenter().y - 352);
        m_game->window().draw(itemSlot);
        if (pInv.items[i] != nullptr)
        {
            sf::Texture itemTexture = m_game->assets().getTexture(getItemTexture(pInv.items[i]));
            sf::Sprite itemSprite(itemTexture);
            itemSprite.setPosition(itemSlot.getPosition());
            std::shared_ptr<sf::Shader> cooldownShader = getShader("Cooldown", "shaders/cooldown.frag");
            cooldownShader->setUniform("texture", sf::Shader::CurrentTexture);
            float cooldown = pInv.itemsLastUsed[i] == 0 ? 1.0f : std::min((m_currentFrame - pInv.itemsLastUsed[i]) / (float)pInv.items[i]->cooldown, 1.0f);
            cooldownShader->setUniform("cooldown", cooldown);
            m_game->window().draw(itemSprite, &*cooldownShader);
            sf::Text consumableCount(std::to_string(pInv.items[i]->count), m_game->assets().getFont("Megaman"), 12);
            consumableCount.setPosition(itemSlot.getPosition().x + 42, itemSlot.getPosition().y + 42);
            consumableCount.setColor(sf::Color::White);
            m_game->window().draw(consumableCount);
        }
    }
    // draw weapon slots and weapon sprites
    // equiped weapon
    itemSlot.setOutlineColor(sf::Color::Red);
    itemSlot.setPosition(m_game->window().getView().getCenter().x + 494, m_game->window().getView().getCenter().y + 288);
    m_game->window().draw(itemSlot);
    auto& pWeapon = m_player->getComponent<CWeapon>();
    sf::Sprite weaponSprite, weaponSprite2;
    sf::Texture weaponTexture = m_game->assets().getTexture(getWeaponTexture(pWeapon.config));
    weaponSprite.setTexture(weaponTexture);
    weaponSprite.setPosition(itemSlot.getPosition());
    std::shared_ptr<sf::Shader> cooldownShader = getShader("Cooldown", "shaders/cooldown.frag");
    cooldownShader->setUniform("texture", sf::Shader::CurrentTexture);
    float weaponCooldown = pWeapon.lastFired == 0 ? 1.0f : std::min((m_currentFrame - pWeapon.lastFired) / (float) pWeapon.config->cooldown, 1.0f);
    cooldownShader->setUniform("cooldown", weaponCooldown);
    m_game->window().draw(weaponSprite, &*cooldownShader);
    // second weapon
    itemSlot.setOutlineColor(sf::Color::White);
    itemSlot.setPosition(m_game->window().getView().getCenter().x + 568, m_game->window().getView().getCenter().y + 288);
    m_game->window().draw(itemSlot);
    if (pInv.secondWeapon != nullptr)
    {
        weaponTexture = m_game->assets().getTexture(getWeaponTexture(pInv.secondWeapon));
        weaponSprite2.setTexture(weaponTexture);
        weaponSprite2.setPosition(itemSlot.getPosition());
        weaponCooldown = pInv.secondWeaponLastFired == 0 ? 1.0f : std::min((m_currentFrame - pInv.secondWeaponLastFired) / (float)pInv.secondWeapon->cooldown, 1.0f);
        cooldownShader->setUniform("cooldown", weaponCooldown);
        m_game->window().draw(weaponSprite2, &*cooldownShader);
    }
}
                 
std::shared_ptr<sf::Shader> Scene_Zelda::getShader(const std::string& shaderName, const std::string& shaderPath)
{
    if (m_shaderMap.find(shaderName) != m_shaderMap.end())
    {
        return m_shaderMap.at(shaderName);
    }

    std::shared_ptr<sf::Shader> shader = std::make_shared<sf::Shader>();
    if (!shader->loadFromFile(shaderPath, sf::Shader::Fragment))
    {
        std::cerr << "Could not load shader file: " << shaderName << std::endl;
    }
    else
    {
        std::cout << "Loaded Shader:    " << shaderName << std::endl;
    }

    m_shaderMap[shaderName] = shader;
    return shader;
}

void Scene_Zelda::updateSwordAnimation(std::shared_ptr<Entity> sword)
{
    std::shared_ptr<Entity> attachedTo = sword->getComponent<CAttachedTo>().attachedEntity;
    auto& aTrans = attachedTo->getComponent<CTransform>();
    if (!attachedTo->isActive())
    {
        sword->destroy();
    }

    if (aTrans.facing == Vec2(-1, 0))
    {
        auto& animation = m_game->assets().getAnimation("SwordRight");
        sword->addComponent<CAnimation>(animation, true);
        sword->addComponent<CBoundingBox>(animation.getSize());
        sword->addComponent<CTransform>(aTrans.pos + Vec2(-58, 0), Vec2(0, 0), Vec2(-1, 1), 0);
    }
    else if (aTrans.facing == Vec2(1, 0))
    {
        auto& animation = m_game->assets().getAnimation("SwordRight");
        sword->addComponent<CAnimation>(animation, true);
        sword->addComponent<CBoundingBox>(animation.getSize());
        sword->addComponent<CTransform>(aTrans.pos + Vec2(58, 0));
    }
    else if (aTrans.facing == Vec2(0, 1))
    {
        auto& animation = m_game->assets().getAnimation("SwordUp");
        sword->addComponent<CAnimation>(animation, true);
        sword->addComponent<CBoundingBox>(animation.getSize());
        sword->addComponent<CTransform>(aTrans.pos + Vec2(0, 58), Vec2(0, 0), Vec2(1, -1), 0);
    }
    else if (aTrans.facing == Vec2(0, -1))
    {
        auto& animation = m_game->assets().getAnimation("SwordUp");
        sword->addComponent<CAnimation>(animation, true);
        sword->addComponent<CBoundingBox>(animation.getSize());
        sword->addComponent<CTransform>(aTrans.pos + Vec2(0, -58));
    }
}

void Scene_Zelda::updateLaserAnimation(std::shared_ptr<Entity> laser)
{
    std::shared_ptr<Entity> attachedTo = laser->getComponent<CAttachedTo>().attachedEntity;
    if (!attachedTo->isActive())
    {
        laser->destroy();
    }

    // lasers begins from the front of the attached entity and stops when it hits an entity that blocks move, or hits the edge of the room
    auto& aTrans = attachedTo->getComponent<CTransform>();
    auto& aBoundingBox = attachedTo->getComponent<CBoundingBox>();
    bool facingLeftOrRight = aTrans.facing == Vec2(1, 0) || aTrans.facing == Vec2(-1, 0);
    float laserGridLength; // this will be used to scale the texture and bounding box size

    // set initial laser length as distance from starting position
    Vec2 roomTopLeftPos = Vec2(floor(aTrans.pos.x / 1280)*1280, floor(aTrans.pos.y / 768)*768);
    Vec2 roomBotRightPos = roomTopLeftPos + Vec2(1280, 768);
    Vec2 startingPos = Vec2(aTrans.pos.x, aTrans.pos.y);
    if (facingLeftOrRight)
    {
        float targetX = aTrans.facing.x == -1 ? roomTopLeftPos.x : roomBotRightPos.x;
        startingPos.x = aTrans.pos.x + aTrans.facing.x * aBoundingBox.halfSize.x;
        laserGridLength = abs(targetX- startingPos.x) / 64;
    }
    else
    {
        float targetY = aTrans.facing.y == -1 ? roomTopLeftPos.y : roomBotRightPos.y;
        startingPos.y = aTrans.pos.y + aTrans.facing.y * aBoundingBox.halfSize.y;
        laserGridLength = abs(targetY- startingPos.y) / 64;
    }

    // check if there are any entities that stop the laser (block move)
    for (auto& e : m_entityManager.getEntities())
    {
        if (e->id() == m_player->id() || e->id() == attachedTo->id() || e->id() == laser->id() || !e->hasComponent<CBoundingBox>() || !e->getComponent<CBoundingBox>().blockMove)
        {
            continue;
        }
        auto& eTrans = e->getComponent<CTransform>();
        if (Physics::EntityIntersect(startingPos, startingPos + aTrans.facing * laserGridLength * 64, e))
        {
            if (facingLeftOrRight && abs(eTrans.pos.x - aTrans.pos.x) / 64 - 1 < laserGridLength)
            {
                laserGridLength = abs(eTrans.pos.x - aTrans.pos.x) / 64 - 1;
            }
            else if (!facingLeftOrRight && abs(eTrans.pos.y - aTrans.pos.y) / 64 - 1 < laserGridLength)
            {
                laserGridLength = abs(eTrans.pos.y - aTrans.pos.y) / 64 - 1;
            }
        }
    }
    Vec2 pos = aTrans.pos + aTrans.facing * 64 * (0.5 + laserGridLength / 2);
    auto& animation = m_game->assets().getAnimation(facingLeftOrRight ? "LaserRight" : "LaserUp");
    laser->addComponent<CAnimation>(animation, true);
    laser->addComponent<CTransform>(pos, Vec2(0, 0), facingLeftOrRight ? Vec2(laserGridLength, 1) : Vec2(1, laserGridLength), 0);
    laser->addComponent<CBoundingBox>(facingLeftOrRight ? Vec2(animation.getSize().x * laserGridLength, animation.getSize().y) : Vec2(animation.getSize().x, animation.getSize().y * laserGridLength));
}

void Scene_Zelda::loadAIConfig(std::shared_ptr<Entity> entity, int rx, int ry, int tx, int ty, std::ifstream& fin)
{
    std::string aiBehaviorName;
    while (fin >> aiBehaviorName)
    {
        if (aiBehaviorName == "End")
        {
            break;
        }
        float s;
        if (aiBehaviorName == "Patrol")
        {
            int n, xi, yi;
            fin >> s >> n;
            std::vector<Vec2> positions;
            for (int i = 0; i < n; i++)
            {
                fin >> xi >> yi;
                positions.push_back(getPosition(rx, ry, xi, yi));
            }
            entity->addComponent<CPatrol>(positions, s);
        }
        else if (aiBehaviorName == "Follow")
        {
            fin >> s;
            entity->addComponent<CFollowPlayer>(getPosition(rx, ry, tx, ty), s);
        }
        else if (aiBehaviorName == "KeepDistance")
        {
            float r;
            fin >> s >> r;
            entity->addComponent<CKeepDistance>(s, r);
        }
        else if (aiBehaviorName == "Enraged")
        {
            int t, sm, dm;
            fin >> t >> sm >> dm;
            entity->addComponent<CEnraged>(s, t, sm, dm);
        }
    }
}

std::shared_ptr<WeaponConfig> Scene_Zelda::loadWeaponConfig(std::string weaponName, std::ifstream& fin)
{
    std::shared_ptr<WeaponConfig> config = std::make_shared<WeaponConfig>();
    config->name = weaponName;
    if (weaponName == "none")
    {
        return config;
    }
    fin >> config->damage >> config->cooldown >> config->lifespan;
    if (weaponName == "gun" || weaponName == "shotgun" || weaponName == "spreadgun")
    {
        fin >> config->bulletSpeed >> config->homingRadius;
    }
    return config;
}

float Scene_Zelda::getLightStrength(std::shared_ptr<Entity> entity)
{
    auto& eTrans = entity->getComponent<CTransform>();
    int eRx = floor(eTrans.pos.x / 1280);
    int eRy = floor(eTrans.pos.y / 768);

    float lightStrength = 0.05;

    if (darkRooms.find(std::make_pair(eRx, eRy)) != darkRooms.end())
    {
        // if the room is dark, light strength is based on its distance to the closest light source and the light source radius
        for (auto& e2 : m_entityManager.getEntities())
        {
            auto& e2Pos = e2->getComponent<CTransform>().pos;
            float dist = eTrans.pos.dist(e2Pos);
            if (e2->hasComponent<CLightSource>() && dist < e2->getComponent<CLightSource>().radius)
            {
                lightStrength = std::max(lightStrength, (e2->getComponent<CLightSource>().radius - dist) / e2->getComponent<CLightSource>().radius);
            }
        }
    }
    else
    {
        // if the room is not dark, light strength is 1
        lightStrength = 1;
    }

    return lightStrength;
}

void Scene_Zelda::saveLevel()
{
    m_fileName += "temp.txt";
    std::ofstream writeFile(m_fileName);
    //Tile Specification :
                //Tile Name RX RY TX TY BM BV
                //	Animation Name    Name      string
                //	Room Coordinate   RX RY     int, int
                //	Tile Position     TX TY     int, int
                //	Blocks Movement   BM        int(1 = true, 0 = false)
                //	Blocks Vision     BV        int(1 = true, 0 = false)
    int width = m_game->window().getSize().x;
    int height = m_game->window().getSize().y;
    for (auto tiles : m_entityManager.getEntities("tile"))
    {
        std::string animationName;
        int RX, RY, TX, TY, BM, BV;
        animationName = tiles->getComponent<CAnimation>().animation.getName() + " ";
        auto transform = tiles->getComponent<CTransform>();
        RX = std::floor(transform.pos.x / width);
        RY = std::floor(transform.pos.y / height);
        TX = (transform.pos.x - RX * float(width)) / 128;
        TY = (transform.pos.y - RY * float(height)) / 128;
        BM = tiles->getComponent<CBoundingBox>().blockMove;
        BV = tiles->getComponent<CBoundingBox>().blockVision;
        writeFile << "Tile " << animationName << RX << " " << RY << " " << TX << " " << TY << " " << BM << " " << BV << "\n";
    }
    //NPC Specification :
                //NPC Name RX RY TX TY BM BV AI ...
                //	Animation Name    Name      string
                //	Room Coordinate   RX RY     int, int
                //	Tile Position     TX TY     int, int
                //	Blocks Movement   BM        int(1 = true, 0 = false)
                //	Blocks Vision     BV        int(1 = true, 0 = false)
                //	AI Behavior Name  AI        string
                //	AI Parameters     ...       (see below)

                //	AI = Follow
                //	... = S
                //	Follow Speed      S         float(speed to follow player)
                //  PathFinding       P         int(1 = true, 0 = false)

                //	AI = Patrol
                //	... = S N X1 Y1 X2 Y2 ... XN YN
                //	Patrol Speed      S         float
                //	Patrol Positions  N         int(number of patrol positions)
                //	Position 1 - N      Xi Yi     int, int(Tile Position of Patrol Position i)

                //	For Example :
                //NPC  Tektite  0  0 15 10 0 0 Patrol 2 4 15 10 15 7 17 7 17 10
                //	- Spawn an NPC with animation name Tektie in room(0, 0) with tile pos(15, 10)
                //	- This NPC does not block movement or vision
                //	- The NPC has a Patrol AI with speed 2 and 4 positions, each in room(0, 0)
                //	Positions : (15, 10) (15, 7) (17, 7) (17, 10)
    for (auto npc : m_entityManager.getEntities("enemy"))
    {
        std::string animationName;
        int RX, RY, TX, TY, BM, BV;
        animationName = npc->getComponent<CAnimation>().animation.getName() + " ";
        auto transform = npc->getComponent<CTransform>();
        RX = std::floor(transform.pos.x / width);
        RY = std::floor(transform.pos.y / height);
        TX = (transform.pos.x - RX * float(width)) / m_tileSize;
        TY = (transform.pos.y - RY * float(height)) / m_tileSize;
        BM = npc->getComponent<CBoundingBox>().blockMove;
        BV = npc->getComponent<CBoundingBox>().blockVision;
        if (npc->hasComponent<CFollowPlayer>())
        {
            std::string npcBehaviour = "Follow ";
            int speed, smartFollow;
            speed = npc->getComponent<CFollowPlayer>().speed;
            smartFollow = npc->getComponent<CFollowPlayer>().smartFollow;
            writeFile << "NPC " << animationName << RX << " " << RY << " " << TX << " " << TY << " " << BM << " " << BV << " " << "2 1 gun 1 30 60 7 0 Follow 2  End" << "\n";
        }
        else if (npc->hasComponent<CPatrol>())
        {
            std::string npcBehaviour = "Patrol ";
            int speed, nPositions;
            nPositions = npc->getComponent<CPatrol>().positions.size();
            speed = npc->getComponent<CPatrol>().speed;
            std::vector<Vec2> positions = npc->getComponent<CPatrol>().positions;

            writeFile << "NPC " << animationName << RX << " " << RY << " " << TX << " " << TY << " " << BM << " " << BV << " " << "2 1 gun 1 300 60 5 0 Patrol 2 2 5 4 5 9 End";

            writeFile << "\n";
        }
    }


    //Player Specification :
    //Player X Y BX BY S
    //	Spawn Position    X Y        int, int
    //	Bounding Box Size BX BY      int, int
    //	Speed             S          float\

    std::string weaponName;
    std::ifstream fin("level1.txt");
    std::shared_ptr<WeaponConfig>
        weaponConfig = loadWeaponConfig(weaponName, fin);
    writeFile << "Player " << m_playerConfig.X << " " << m_playerConfig.Y << " " << m_playerConfig.CX << " " << m_playerConfig.CY << " " << m_playerConfig.SPEED << " " << m_playerConfig.HEALTH << " gun 1 30 60 7 0" << "\n";


    writeFile.close();
    std::cout << "Game is saved to " << m_fileName << "\n";

    // After writing is done
}

void Scene_Zelda::destroyEnemy(std::shared_ptr<Entity> entity)
{
    m_game->playSound("EnemyDie");
    auto& explosion = m_entityManager.addEntity("explosion");
    explosion->addComponent<CAnimation>(m_game->assets().getAnimation("Explosion"), false);
    explosion->addComponent<CTransform>(entity->getComponent<CTransform>().pos);
    entity->destroy();
}

std::string Scene_Zelda::getWeaponAnimation(std::shared_ptr<WeaponConfig> weapon)
{
    if (weapon->name == "laser")
    {
        return "Laser";
    }
    else if (weapon->name == "gun")
    {
        // TODO different animation for gun with homing bullet
        return "Gun";
    }
    else if (weapon->name == "shotgun")
    {
        return "Shotgun";
    }
    else if (weapon->name == "spreadgun")
    {
        return "Spreadgun";
    }
}

std::string Scene_Zelda::getWeaponTexture(std::shared_ptr<WeaponConfig> weapon)
{
    if (weapon->name == "sword")
    {
        return "TexSwordRight";
    }
    else if (weapon->name == "laser")
    {
        return "TexLaser";
    }
    else if (weapon->name == "gun")
    {
        // TODO different texture for gun with homing bullet
        return "TexGun";
    }
    else if (weapon->name == "shotgun")
    {
        return "TexShotgun";
    }
    else if (weapon->name == "spreadgun")
    {
        return "TexSpreadgun";
    }
}

std::string Scene_Zelda::getItemTexture(std::shared_ptr<ItemConfig> item)
{
    if (item->name == "health")
    {
        return "TexHealthPot";
    }
    else if (item->name == "speed")
    {
        return "TexSpeedPot";
    }
    else if (item->name == "bomb")
    {
        return "TexBomb";
    }
    else if (item->name == "poison")
    {
        return "TexPoison";
    }
}

void Scene_Zelda::applyStatuses(std::vector<std::string> statuses, std::shared_ptr<Entity> target)
{
    for (auto& s : statuses)
    {
        if (s == "poison")
        {
            target->addComponent<CPoisoned>(360);
        }
    }
}
                                                                          
// Copyright (C) David Churchill - All Rights Reserved
// COMP4300 - 2022-09 - Assignment 4
// Written by David Churchill (dave.churchill@gmail.com)
// Unauthorized copying of these files are strictly prohibited
// Distributed only for course work at Memorial University
// If you see this file online please contact email above
