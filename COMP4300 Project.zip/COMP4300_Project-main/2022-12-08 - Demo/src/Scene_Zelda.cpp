///\/\/\\\\\//////\/\/\/\\\///\\\/\/\/\\\\\//////\/\/\/\\\///\\\
//
//  Assignment       COMP4300 - Assignment 4
//  Professor:       David Churchill
//  Year / Term:     2022-09
//  File Name:       Scene_Zelda.cpp
// 
//  Student Name:    Yeong Shu Chun
//  Student User:    yschun
//  Student Email:   yschun@mun.ca
//  Student ID:      201623048
//  Group Member(s): [enter student name(s)]
//
///\/\/\\\\\//////\/\/\/\\\///\\\/\/\/\\\\\//////\/\/\/\\\///\\\
                                                                          
#include "Scene_Zelda.h"
#include "Common.h"
#include "Physics.h"
#include "Assets.h"
#include "GameEngine.h"
#include "Components.h"
#include <cmath>

Scene_Zelda::Scene_Zelda(GameEngine* game, const std::string& levelPath)
    : Scene(game)
    , m_levelPath(levelPath)
{
    init(m_levelPath);
}


void Scene_Zelda::init(const std::string& levelPath)
{
    loadLevel(levelPath);

    // Register the actions required to play the game

    registerAction(sf::Keyboard::Escape, "QUIT");
    registerAction(sf::Keyboard::P, "PAUSE");
    registerAction(sf::Keyboard::Y, "TOGGLE_FOLLOW");      // Toggle drawing (T)extures
    registerAction(sf::Keyboard::T, "TOGGLE_TEXTURE");      // Toggle drawing (T)extures
    registerAction(sf::Keyboard::C, "TOGGLE_COLLISION");    // Toggle drawing (C)ollision Boxes
    registerAction(sf::Keyboard::W, "UP");
    registerAction(sf::Keyboard::A, "LEFT");
    registerAction(sf::Keyboard::S, "DOWN");
    registerAction(sf::Keyboard::D, "RIGHT");
    registerAction(sf::Keyboard::Space, "ATTACK");
    registerAction(sf::Keyboard::LShift, "DODGE");
}
                                                                          
void Scene_Zelda::loadLevel(const std::string& filename)
{
    m_entityManager = EntityManager();

    // Load the level file and put all entities in the manager
    // Use the getPosition() function below to convert room-tile coords to game world coords
    std::ifstream fin(filename);
    std::string entityName;
    while (fin >> entityName)
    {
        if (entityName == "Tile")
        {
            std::string animationName;
            int rx, ry, tx, ty, bm, bv;
            fin >> animationName >> rx >> ry >> tx >> ty >> bm >> bv;
            auto tile = m_entityManager.addEntity("tile");
            Animation animation = m_game->assets().getAnimation(animationName);
            tile->addComponent<CAnimation>(animation, true);
            tile->addComponent<CTransform>(getPosition(rx, ry, tx, ty));
            tile->addComponent<CBoundingBox>(animation.getSize(), bm, bv);
        }
        else if (entityName == "NPC")
        {
            std::string animationName, aiBehaviorName, weaponName;
            int rx, ry, tx, ty, bm, bv, h, d;
            float s;
            fin >> animationName >> rx >> ry >> tx >> ty >> bm >> bv >> h >> d >> weaponName;
            std::shared_ptr<WeaponConfig> weaponConfig = loadWeaponConfig(weaponName, fin);
            auto enemy = m_entityManager.addEntity("enemy");
            auto& animation = m_game->assets().getAnimation(animationName);
            enemy->addComponent<CAnimation>(animation, true);
            enemy->addComponent<CTransform>(getPosition(rx, ry, tx, ty));
            enemy->addComponent<CBoundingBox>(animation.getSize(), bm, bv);
            enemy->addComponent<CHealth>(h, h);
            enemy->addComponent<CDamage>(d, "enemy");
            loadAIConfig(enemy, rx, ry, tx, ty, fin);
            if (animationName == "MoveTile")
            {
                enemy->removeComponent<CHealth>();
                enemy->removeComponent<CDamage>();
                enemy->removeComponent<CWeapon>();
            }
            enemy->addComponent<CWeapon>(weaponConfig);

        }
        else if (entityName == "Player")
        {
            std::string weaponName;
            fin >> m_playerConfig.X >> m_playerConfig.Y >> m_playerConfig.CX >> m_playerConfig.CY >> m_playerConfig.SPEED >> m_playerConfig.HEALTH >> weaponName;
            std::shared_ptr<WeaponConfig> weaponConfig = loadWeaponConfig(weaponName, fin);
            m_playerConfig.WEAPON = weaponConfig;
        }
        else if (entityName == "DarkRoom")
        {
            int rx, ry;
            fin >> rx >> ry;
            darkRooms.insert(std::make_pair(rx, ry));
        }
    }

    m_game->playSound("MusicPlay");
    spawnPlayer();
}

Vec2 Scene_Zelda::getPosition(int rx, int ry, int tx, int ty) const
{
    int x = rx * 1280 + tx * 64 + 32;
    int y = ry * 768 + ty * 64 + 32;

    return Vec2(x, y);
}
                                                                          
void Scene_Zelda::spawnPlayer()
{
    m_player = m_entityManager.addEntity("player");
    m_player->addComponent<CTransform>(Vec2(m_playerConfig.X, m_playerConfig.Y));
    m_player->addComponent<CAnimation>(m_game->assets().getAnimation("StandDown"), true);
    m_player->addComponent<CBoundingBox>(Vec2(m_playerConfig.CX, m_playerConfig.CY), true, false);
    m_player->addComponent<CHealth>(m_playerConfig.HEALTH, m_playerConfig.HEALTH);
    m_player->addComponent<CWeapon>(m_playerConfig.WEAPON);
    m_player->addComponent<CLightSource>(500);
}

void Scene_Zelda::spawnSword(std::shared_ptr<Entity> entity, int damage, int lifespan)
{
    auto sword = m_entityManager.addEntity("sword");
    sword->addComponent<CDamage>(damage, entity->id() == m_player->id() ? "player" : "enemy");
    sword->addComponent<CLifeSpan>(lifespan, m_currentFrame);
    sword->addComponent<CAttachedTo>(entity);

    if (entity == m_player)
    {
        m_game->playSound("Slash");
    }
}

void Scene_Zelda::spawnBullet(std::shared_ptr<Entity> entity, float theta, int speed, int homingRadius, int damage, int lifespan)
{
    auto& eTrans = entity->getComponent<CTransform>();
    auto bullet = m_entityManager.addEntity("bullet");

    std::string bulletAnimationName = homingRadius > 0 ? "HomingBullet" : "Bullet";
    Animation animation = m_game->assets().getAnimation(bulletAnimationName);
    bullet->addComponent<CTransform>(Vec2(eTrans.pos.x, eTrans.pos.y), Vec2(speed * cos(theta), speed * sin(theta)), Vec2(1, 1), 0);
    bullet->addComponent<CAnimation>(animation, true);
    bullet->addComponent<CBoundingBox>(animation.getSize());
    bullet->addComponent<CLifeSpan>(120, m_currentFrame);
    bool playerSpawned = entity->id() == m_player->id();
    bullet->addComponent<CDamage>(damage, playerSpawned ? "player" : "enemy");
    bullet->addComponent<CHoming>(homingRadius, playerSpawned ? "enemy" : "player");
    if (!playerSpawned)
    {
        std::shared_ptr<sf::Shader> shader = getShader("EnemyBullet", "shaders/bullet.frag");
        bullet->addComponent<CShader>(shader);
        shader->setUniform("texture", sf::Shader::CurrentTexture);
        shader->setUniform("bulletColor", sf::Vector3f(1, 0, 0));
    }
    if (homingRadius > 0)
    {
        bullet->addComponent<CRotate>();
    }
}

void Scene_Zelda::spawnLaser(std::shared_ptr<Entity> entity, int damage, int lifespan)
{
    auto& eTrans = entity->getComponent<CTransform>();

    auto laser = m_entityManager.addEntity("laser");
    laser->addComponent<CLifeSpan>(lifespan, m_currentFrame);
    laser->addComponent<CDamage>(damage, entity == m_player ? "player" : "enemy");
    laser->addComponent<CAttachedTo>(entity);
    updateLaserAnimation(laser);
}

void Scene_Zelda::attack(std::shared_ptr<Entity> entity)
{
    auto& pTrans = m_player->getComponent<CTransform>();
    auto& eTrans = entity->getComponent<CTransform>();
    auto& eWeapon = entity->getComponent<CWeapon>();
    std::string weaponName = eWeapon.config->name;

    if (weaponName == "gun")
    {
        if (entity->id() == m_player->id())
        {
            spawnBullet(m_player, atan2f(pTrans.facing.y, pTrans.facing.x), eWeapon.config->bulletSpeed, eWeapon.config->homingRadius, eWeapon.config->damage, eWeapon.config->lifespan);
        }
        else
        {
            Vec2 diff = pTrans.pos - eTrans.pos;
            spawnBullet(entity, atan2f(diff.y, diff.x), eWeapon.config->bulletSpeed, eWeapon.config->homingRadius, eWeapon.config->damage, eWeapon.config->lifespan);
        }
    }
    else if (weaponName == "spreadgun")
    {
        // spawn 4 bullets in the cardinal directions
        for (int i = 0; i < 4; i++)
        {
            spawnBullet(entity, i*3.1415/2, eWeapon.config->bulletSpeed, eWeapon.config->homingRadius, eWeapon.config->damage, eWeapon.config->lifespan);
        }
    }
    else if (weaponName == "shotgun")
    {
        float thetaInitial;
        if (entity->id() == m_player->id())
        {
            thetaInitial = atan2f(pTrans.facing.y, pTrans.facing.x);
        }
        else
        {
            Vec2 diff = pTrans.pos - eTrans.pos;
            thetaInitial = atan2f(diff.y, diff.x);
        }
        spawnBullet(entity, thetaInitial, eWeapon.config->bulletSpeed, eWeapon.config->homingRadius, eWeapon.config->damage, eWeapon.config->lifespan);
        // fires additional bullets 15 and 30 degrees away
        float offsets[] = { 0.261799 , 0.523598 };
        for (float offset : offsets)
        {
            spawnBullet(entity, thetaInitial + offset, eWeapon.config->bulletSpeed, eWeapon.config->homingRadius, eWeapon.config->damage, eWeapon.config->lifespan);
            spawnBullet(entity, thetaInitial - offset, eWeapon.config->bulletSpeed, eWeapon.config->homingRadius, eWeapon.config->damage, eWeapon.config->lifespan);
        }
    }
    else if (weaponName == "laser")
    {
        spawnLaser(entity, eWeapon.config->damage, eWeapon.config->lifespan);
    }
    else if (weaponName == "sword")
    {
        spawnSword(entity, eWeapon.config->damage, eWeapon.config->lifespan);
    }
}

void Scene_Zelda::dodge(std::shared_ptr<Entity> entity)
{
    auto& eTrans = entity->getComponent<CTransform>();
    auto dodge = m_entityManager.addEntity("dodge");

    if (eTrans.facing == Vec2(-1, 0))
    {
        eTrans.velocity.x = -m_playerConfig.SPEED * 1.25;
    }
    else if (eTrans.facing == Vec2(1, 0))
    {
        eTrans.velocity.x = m_playerConfig.SPEED * 1.25;
    }

    else if (eTrans.facing == Vec2(0, 1))
    {
        eTrans.velocity.y = m_playerConfig.SPEED * 1.25;
    }
    else if (eTrans.facing == Vec2(0, -1))
    {
        eTrans.velocity.y = -m_playerConfig.SPEED * 1.25;
    }
    dodge->addComponent<CLifeSpan>(20, m_currentFrame);
    m_player->addComponent<CInvincibility>(20);
}

void Scene_Zelda::update()
{
    m_entityManager.update();

    if (!m_paused)
    {
        sAI();
        sMovement();
        sStatus();
        sCollision();
        sAnimation();
        m_currentFrame++;
    }
    sCamera();
}

void Scene_Zelda::sMovement()
{
    auto& pInput = m_player->getComponent<CInput>();
    auto& pTrans = m_player->getComponent<CTransform>();
    auto& pWeapon = m_player->getComponent<CWeapon>();
    bool inDodge = m_entityManager.getEntities("dodge").size() == 1;

    if (!inDodge) 
    {
        pTrans.velocity = Vec2(0, 0);
    }

    if (pInput.left && !pInput.right && !pInput.up && !pInput.down &&!pInput.dodge && !inDodge)
    {
        pTrans.velocity.x = -m_playerConfig.SPEED;
        pTrans.facing = Vec2(-1, 0);
    }
    else if (pInput.right && !pInput.left && !pInput.up && !pInput.down && !pInput.dodge && !inDodge)
    {
        pTrans.velocity.x = m_playerConfig.SPEED;
        pTrans.facing = Vec2(1, 0);
    }
    else if (pInput.up && !pInput.left && !pInput.right && !pInput.down && !pInput.dodge && !inDodge)
    {
        pTrans.velocity.y = -m_playerConfig.SPEED;
        pTrans.facing = Vec2(0, -1);
    }
    else if (pInput.down && !pInput.left && !pInput.right && !pInput.up && !pInput.dodge && !inDodge)
    {
        pTrans.velocity.y = m_playerConfig.SPEED;
        pTrans.facing = Vec2(0, 1);
    }

    if (pInput.attack && pWeapon.canAttack(m_currentFrame) && !pInput.dodge && !inDodge)
    {
        pWeapon.lastFired = m_currentFrame;
        attack(m_player);
    }

    if (pInput.dodge && !pInput.attack && !inDodge)
    {
        dodge(m_player);
    }

    for (auto& e : m_entityManager.getEntities())
    {
        auto& eTrans = e->getComponent<CTransform>();
        if (e->hasComponent<CTransform>())
        {
            eTrans.prevPos = eTrans.pos;
            eTrans.pos += eTrans.velocity;
            if (e->id() != m_player->id())
            {
                // NPC face whichever direction has the highest velocity component
                if (eTrans.velocity == Vec2(0, 0))
                {
                    eTrans.facing = Vec2(0, 1);
                }
                else
                {
                    eTrans.facing = abs(eTrans.velocity.x) > abs(eTrans.velocity.y) ? Vec2(eTrans.velocity.x, 0) / abs(eTrans.velocity.x)
                                                                                            : Vec2(0, eTrans.velocity.y) / abs(eTrans.velocity.y);
                }
            }
            if (e->hasComponent<CRotate>())
            {
                eTrans.angle = atan2f(eTrans.velocity.y, eTrans.velocity.x) * 180 / 3.1415;
            }
        }
        if (e->hasComponent<CHoming>())
        {
            for (auto& e2 : m_entityManager.getEntities(e->getComponent<CHoming>().targetTag))
            {
                auto& e2Trans = e2->getComponent<CTransform>();
                bool isMoveTile = e2->getComponent<CAnimation>().animation.getName() == "MoveTile"; //prevent homing toward tile
                if (eTrans.pos.dist(e2Trans.pos) < e->getComponent<CHoming>().radius && !isMoveTile)
                {
                    float currSpeed = eTrans.velocity.dist(Vec2(0, 0));
                    Vec2 diff = e2Trans.pos - eTrans.pos;
                    Vec2 desired = diff / diff.dist(Vec2(0, 0)) * currSpeed;
                    Vec2 steering = (desired - eTrans.velocity) * 0.3;
                    Vec2 adjusted = eTrans.velocity + steering;
                    // make the speed the same as it was previously
                    eTrans.velocity = adjusted / adjusted.dist(Vec2(0,0)) * currSpeed;
                    break;
                }
            }
        }
    }
}

void Scene_Zelda::sDoAction(const Action& action)
{                        
    auto& pInput = m_player->getComponent<CInput>();

    if (action.type() == "START")
    {
        
             if (action.name() == "PAUSE") { setPaused(!m_paused); }
        else if (action.name() == "QUIT") { onEnd(); }
        else if (action.name() == "TOGGLE_FOLLOW") { m_follow = !m_follow; }
        else if (action.name() == "TOGGLE_TEXTURE") { m_drawTextures = !m_drawTextures; }
        else if (action.name() == "TOGGLE_COLLISION") { m_drawCollision = !m_drawCollision; }
        else if (action.name() == "UP") { pInput.up = true; }
        else if (action.name() == "DOWN") { pInput.down = true; }
        else if (action.name() == "LEFT") { pInput.left = true; }
        else if (action.name() == "RIGHT") { pInput.right = true; }
        else if (action.name() == "ATTACK") { pInput.attack = true; }
        else if (action.name() == "DODGE") { pInput.dodge = true; }
    }
    else if (action.type() == "END")
    {
             if (action.name() == "UP") { pInput.up = false; }
        else if (action.name() == "DOWN") { pInput.down = false; }
        else if (action.name() == "LEFT") { pInput.left = false; }
        else if (action.name() == "RIGHT") { pInput.right = false; }
        else if (action.name() == "ATTACK") { pInput.attack = false; }
        else if (action.name() == "DODGE") { pInput.dodge = false; }
    }
    
}

void Scene_Zelda::sAI()
{
    auto& pTrans = m_player->getComponent<CTransform>();
    for (auto& e : m_entityManager.getEntities("enemy"))
    {
        auto& eTrans = e->getComponent<CTransform>();
        float speed = 0;
        if (e->hasComponent<CFollowPlayer>())
        {
            auto& eFollow = e->getComponent<CFollowPlayer>();
            speed = eFollow.speed;;
            bool inPlayersRoom = Vec2(floor(eTrans.pos.x / 1280), floor(eTrans.pos.y / 768)) == Vec2(floor(pTrans.pos.x / 1280), floor(pTrans.pos.y / 768));
            bool visionBlocked = false;
            if (!inPlayersRoom)
            {
                // enemies cannot see the player in another room
                visionBlocked = true;
            }
            else
            {
                for (auto& e2 : m_entityManager.getEntities())
                {
                    if (e2->hasComponent<CBoundingBox>() && e2->getComponent<CBoundingBox>().blockVision && Physics::EntityIntersect(eTrans.pos, pTrans.pos, e2))
                    {
                        visionBlocked = true;
                        break;
                    }
                }
            }
            if (!visionBlocked)
            {
                Vec2 diff = pTrans.pos - eTrans.pos;
                eTrans.velocity = diff;
            }
            else if (m_currentFrame % 60 == 0)
            {
                int randTheta = (rand() % 360) * 3.1415 / 180;
                eTrans.velocity = Vec2(cos(randTheta), sin(randTheta));
            }
        }
        else if (e->hasComponent<CPatrol>())
        {
            auto& ePatrol = e->getComponent<CPatrol>();
            speed = ePatrol.speed;
            if (eTrans.pos.dist(ePatrol.positions[ePatrol.currentPosition]) < 5)
            {
                ePatrol.currentPosition = (ePatrol.currentPosition + 1) % ePatrol.positions.size();
            }
            Vec2 diff = ePatrol.positions[ePatrol.currentPosition] - eTrans.pos;
            eTrans.velocity = diff;
        }
        else if (e->hasComponent<CKeepDistance>())
        {
            auto& eKeepDist = e->getComponent<CKeepDistance>();
            speed = eKeepDist.speed;
            if (eTrans.pos.dist(pTrans.pos) < eKeepDist.range)
            {
                Vec2 diff = eTrans.pos - pTrans.pos;
                eTrans.velocity = diff;
            }
            else
            {
                eTrans.velocity = Vec2(0, 0);
            }
        }
        if (e->hasComponent<CEnraged>())
        {
            auto& eEnraged = e->getComponent<CEnraged>();
            if (e->getComponent<CHealth>().current <= eEnraged.threshold && !eEnraged.isEnraged)
            {
                eEnraged.isEnraged = true;
                speed *= eEnraged.speedScale;
                e->getComponent<CDamage>().damage *= eEnraged.dmgScale;
                if (e->hasComponent<CWeapon>())
                {
                    e->getComponent<CWeapon>().config->cooldown /= eEnraged.speedScale;
                    e->getComponent<CWeapon>().config->damage *= eEnraged.dmgScale;
                }
                std::shared_ptr<sf::Shader> shader = getShader("EnemyEnraged", "shaders/enraged.frag");
                e->addComponent<CShader>(shader);
                shader->setUniform("texture", sf::Shader::CurrentTexture);
                shader->setUniform("time", time.getElapsedTime().asSeconds());
            }
            else if (eEnraged.isEnraged)
            {
                e->getComponent<CShader>().shader->setUniform("time", time.getElapsedTime().asSeconds());
                speed *= eEnraged.speedScale;
            }
        }
        if (eTrans.velocity != Vec2(0, 0)) 
        { 
            eTrans.velocity = eTrans.velocity / eTrans.velocity.dist(Vec2(0, 0)) * speed; 
        }

        if (e->hasComponent<CWeapon>() && e->getComponent<CWeapon>().canAttack(m_currentFrame))
        {
            auto& eWeapon = e->getComponent<CWeapon>();
            eWeapon.lastFired = m_currentFrame;
            attack(e);
        }
    }
}

void Scene_Zelda::sStatus()
{
    for (auto e : m_entityManager.getEntities())
    {
        if (e->hasComponent<CLifeSpan>())
        {
            if (m_currentFrame > e->getComponent<CLifeSpan>().frameCreated + e->getComponent<CLifeSpan>().lifespan)
            {
                e->destroy();
            }
        }
        if (e->hasComponent<CInvincibility>())
        {
            if (--e->getComponent<CInvincibility>().iframes == 0)
            {
                e->removeComponent<CInvincibility>();
            }
        }
    }
}

void Scene_Zelda::sCollision()
{
    auto& pTrans = m_player->getComponent<CTransform>();

    for (auto& t : m_entityManager.getEntities("tile"))
    {
        for (auto& e : m_entityManager.getEntities())
        {
            if (e->tag() != "tile" && t->id() != e->id() && e->hasComponent<CBoundingBox>())
            {
                // entity tile collision
                auto& tTrans = t->getComponent<CTransform>();
                auto& eTrans = e->getComponent<CTransform>();
                Vec2 overlap = Physics::GetOverlap(t, e);
                if (overlap.x > 0 && overlap.y > 0)
                {
                    if (t->getComponent<CBoundingBox>().blockMove)
                    {
                        Vec2 prevOverlap = Physics::GetPreviousOverlap(t, e);
                        if (prevOverlap.x > 0)
                        {
                            bool isBelow = eTrans.pos.y > tTrans.pos.y;
                            eTrans.pos.y = eTrans.pos.y + (isBelow ? overlap.y : -overlap.y);
                        }
                        else if (prevOverlap.y > 0)
                        {
                            bool isOnRight = eTrans.pos.x > tTrans.pos.x;
                            eTrans.pos.x = eTrans.pos.x + (isOnRight ? overlap.x : -overlap.x);
                        }
                        if (e->tag() == "bullet")
                        {
                            e->destroy();
                        }
                    }
                    else if (t->getComponent<CAnimation>().animation.getName() == "Heart" && e->hasComponent<CHealth>())
                    {
                        // entity heart collision
                        m_game->playSound("GetItem");
                        e->getComponent<CHealth>().current = e->getComponent<CHealth>().max;
                        t->destroy();
                    }
                }
            }
        }

        if (t->getComponent<CAnimation>().animation.getName() == "Black")
        {
            // black tile teleport
            Vec2 pOverlap = Physics::GetOverlap(t, m_player);
            // teleports if player is half way in the black tile
            if (pOverlap.x > 32 && pOverlap.y > 32)
            {
                EntityVec blackTiles;
                for (auto& t2 : m_entityManager.getEntities("tile"))
                {
                    if (t2->getComponent<CAnimation>().animation.getName() == "Black")
                    {
                        blackTiles.push_back(t2);
                    }
                }
                auto& newTile = blackTiles[rand() % blackTiles.size()];
                pTrans.pos = newTile->getComponent<CTransform>().pos + Vec2(0, 64);
            }
        }
    }

    // entity entity collisions
    for (auto e : m_entityManager.getEntities())
    {
        for (auto& e2: m_entityManager.getEntities())
        {
            bool isMoveTile = e->getComponent<CAnimation>().animation.getName() == "MoveTile";
            if (isMoveTile && e2->id() == m_player->id())
            {
                // player moving tile collision
                Vec2 overlap = Physics::GetOverlap(e, m_player);
                if (overlap.x > 0 && overlap.y > 0)
                {
                    Vec2 eVelocity = e->getComponent<CTransform>().velocity;
                    pTrans.pos += eVelocity;
                }
            }

            // damage calculations
            bool alreadyDamaged = e2->getComponent<CDamage>().entitiesDamaged.find(e->id()) != e2->getComponent<CDamage>().entitiesDamaged.end();
            bool cannotBeDamaged = !e->isActive() || !e2->isActive() || e->id() == e2->id() || isMoveTile ||
                                    !e2->hasComponent<CDamage>() || e2->getComponent<CDamage>().dmgSource == e->tag() || !e->hasComponent<CHealth>() || e->hasComponent<CInvincibility>();
            if (alreadyDamaged || cannotBeDamaged)
            {
                continue;
            }

            Vec2 sOverlap = Physics::GetOverlap(e, e2);
            if (sOverlap.x > 0 && sOverlap.y > 0)
            {
                e->getComponent<CHealth>().current -= e2->getComponent<CDamage>().damage;
                if (e == m_player)
                {
                    m_game->playSound("LinkHurt");
                    if (m_player->getComponent<CHealth>().current <= 0)
                    {
                        m_game->playSound("LinkDie");
                        m_player->destroy();
                        spawnPlayer();
                    }
                    else
                    {
                        m_player->addComponent<CInvincibility>(30);
                    }
                }
                else
                {
                    m_game->playSound("EnemyHit");
                    if (e->getComponent<CHealth>().current <= 0)
                    {
                        m_game->playSound("EnemyDie");
                        auto& explosion = m_entityManager.addEntity("explosion");
                        explosion->addComponent<CAnimation>(m_game->assets().getAnimation("Explosion"), false);
                        explosion->addComponent<CTransform>(e->getComponent<CTransform>().pos);
                        e->destroy();
                    }
                }
                if (e2->tag() == "bullet")
                {
                    e2->destroy();
                }
                else if (e2->tag() == "sword" || e2->tag() == "laser")
                {
                    e2->getComponent<CDamage>().entitiesDamaged.insert(e->id());
                }
            }
        }
    }
}

void Scene_Zelda::sAnimation()
{
    auto& pTrans = m_player->getComponent<CTransform>();
    auto& pAnim = m_player->getComponent<CAnimation>();
    bool inDodge = m_entityManager.getEntities("dodge").size() == 1;

    bool swingingSword = false;
    for (auto& s : m_entityManager.getEntities("sword"))
    {
        if (s->getComponent<CAttachedTo>().attachedEntity == m_player)
        {
            swingingSword = true;
        }
    }

    bool isRunning = pTrans.velocity != Vec2(0, 0) && !inDodge;
    pTrans.scale = Vec2(1, 1);

    if (pTrans.facing == Vec2(-1, 0))
    {
        pTrans.scale.x = -1;
        if (swingingSword)
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("AtkRight"), true);
        }
        else if (isRunning && pAnim.animation.getName() != "RunRight")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("RunRight"), true);
        }
        else if (!isRunning && !inDodge)
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("StandRight"), true);
        }
        else if (inDodge && pAnim.animation.getName() != "DodgeR")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("DodgeR"), true);
        }
    }
    else if (pTrans.facing == Vec2(1, 0))
    {
        if (swingingSword)
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("AtkRight"), true);
        }
        else if (isRunning && pAnim.animation.getName() != "RunRight")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("RunRight"), true);
        }
        else if (!isRunning && !inDodge)
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("StandRight"), true);
        }
        else if (inDodge && pAnim.animation.getName() != "DodgeR")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("DodgeR"), true);
        }
    }
    else if (pTrans.facing == Vec2(0, 1))
    {
        if (swingingSword)
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("AtkDown"), true);
        }
        else if (isRunning && pAnim.animation.getName() != "RunDown")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("RunDown"), true);
        }
        else if (!isRunning && !inDodge)
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("StandDown"), true);
        }
        else if (inDodge && pAnim.animation.getName() != "Dodge")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("Dodge"), true);
        }
    }
    else if (pTrans.facing == Vec2(0, -1))
    {
        if (swingingSword)
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("AtkUp"), true);
        }
        else if (isRunning && pAnim.animation.getName() != "RunUp")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("RunUp"), true);
        }
        else if (!isRunning && !inDodge)
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("StandUp"), true);
        }
        else if (inDodge && pAnim.animation.getName() != "Dodge")
        {
            m_player->addComponent<CAnimation>(m_game->assets().getAnimation("Dodge"), true);
        }
    }

    for (auto s : m_entityManager.getEntities("sword"))
    {
        updateSwordAnimation(s);
    }

    for (auto l : m_entityManager.getEntities("laser"))
    {
        updateLaserAnimation(l);
    }

    for (auto e : m_entityManager.getEntities())
    {
        if (e->hasComponent<CAnimation>())
        {
            auto& anim = e->getComponent<CAnimation>();
            anim.animation.update();
            if (!anim.repeat && anim.animation.hasEnded())
            {
                e->destroy();
            }
        }
    }
}

void Scene_Zelda::sCamera()
{
    // get the current view, which we will modify in the if-statement below
    sf::View view = m_game->window().getView();

    Vec2 pPos = m_player->getComponent<CTransform>().pos;

    if (m_follow)
    {
        // calculate view for player follow camera
        view.setCenter(pPos.x, pPos.y);
    }
    else
    {
        // calcluate view for room-based camera
        int rx = floor(pPos.x / 1280);
        int ry = floor(pPos.y / 768);
        int x = rx * 1280 + 640;
        int y = ry * 768 + 384;
        view.setCenter(x, y);
    }
                                                                          
    // then set the window view
    m_game->window().setView(view);
}

void Scene_Zelda::onEnd()
{
    m_game->assets().getSound("MusicPlay").stop();
    m_game->playSound("MusicTitle");
    m_game->changeScene("MENU", nullptr, true);
}

void Scene_Zelda::sRender()
{
    // RENDERING DONE FOR YOU

    m_game->window().clear(sf::Color(72, 50, 72));
    sf::RectangleShape tick({ 1.0f, 6.0f });
    tick.setFillColor(sf::Color::Black);

    // draw all Entity textures / animations
    if (m_drawTextures)
    {
        for (auto e : m_entityManager.getEntities())
        {
            // set the darkness of the entity based on light strength
            float lightStrength = getLightStrength(e);
            if (!e->hasComponent<CShader>())
            {
                std::shared_ptr<sf::Shader> shader = getShader("DarkTile", "shaders/dark.frag");
                e->addComponent<CShader>(shader);
                shader->setUniform("texture", sf::Shader::CurrentTexture);
            }
            e->getComponent<CShader>().shader->setUniform("lightStrength", lightStrength);

            auto& transform = e->getComponent<CTransform>();
            sf::Color c = sf::Color::White;
            if (e->hasComponent<CInvincibility>())
            {
                c = sf::Color(255, 255, 255, 128);
            }
                                                                          
            if (e->hasComponent<CAnimation>())
            {
                auto& animation = e->getComponent<CAnimation>().animation;
                animation.getSprite().setRotation(transform.angle);
                animation.getSprite().setPosition(transform.pos.x, transform.pos.y);
                animation.getSprite().setScale(transform.scale.x, transform.scale.y);
                animation.getSprite().setColor(c);
                if (e->hasComponent<CShader>())
                {
                    sf::Shader & shader = *e->getComponent<CShader>().shader;
                    m_game->window().draw(animation.getSprite(), &*e->getComponent<CShader>().shader);
                }
                else
                {
                    m_game->window().draw(animation.getSprite());
                }
            }

            // only show health bar if the entity is sufficiently lit
            if (e->hasComponent<CHealth>() && lightStrength > 0.1)
            {
                auto& h = e->getComponent<CHealth>();
                Vec2 size(64, 6);
                sf::RectangleShape rect({ size.x, size.y });
                rect.setPosition(transform.pos.x - 32, transform.pos.y - 48);
                rect.setFillColor(sf::Color(96, 96, 96));
                rect.setOutlineColor(sf::Color::Black);
                rect.setOutlineThickness(2);
                m_game->window().draw(rect);

                float ratio = (float)(h.current) / h.max;
                size.x *= ratio;
                rect.setSize({ size.x, size.y });
                rect.setFillColor(sf::Color(255, 0, 0));
                rect.setOutlineThickness(0);
                m_game->window().draw(rect);

                for (int i = 0; i < h.max; i++)
                {
                    tick.setPosition(rect.getPosition() + sf::Vector2f(i * 64 * 1 / h.max, 0));
                    m_game->window().draw(tick);
                }
            }
        }
    }

    // draw all Entity collision bounding boxes with a rectangleshape
    if (m_drawCollision)
    {
        sf::CircleShape dot(4);
        dot.setFillColor(sf::Color::Black);
        for (auto e : m_entityManager.getEntities())
        {
            if (e->hasComponent<CBoundingBox>())
            {
                auto& box = e->getComponent<CBoundingBox>();
                auto& transform = e->getComponent<CTransform>();
                sf::RectangleShape rect;
                rect.setSize(sf::Vector2f(box.size.x - 1, box.size.y - 1));
                rect.setOrigin(sf::Vector2f(box.halfSize.x, box.halfSize.y));
                rect.setPosition(transform.pos.x, transform.pos.y);
                rect.setFillColor(sf::Color(0, 0, 0, 0));

                if (box.blockMove && box.blockVision) { rect.setOutlineColor(sf::Color::Black); }
                if (box.blockMove && !box.blockVision) { rect.setOutlineColor(sf::Color::Blue); }
                if (!box.blockMove && box.blockVision) { rect.setOutlineColor(sf::Color::Red); }
                if (!box.blockMove && !box.blockVision) { rect.setOutlineColor(sf::Color::White); }
                rect.setOutlineThickness(1);
                m_game->window().draw(rect);
            }

            if (e->hasComponent<CPatrol>())
            {
                auto& patrol = e->getComponent<CPatrol>().positions;
                for (size_t p = 0; p < patrol.size(); p++)
                {
                    dot.setPosition(patrol[p].x, patrol[p].y);
                    m_game->window().draw(dot);
                }
            }

            if (e->hasComponent<CFollowPlayer>())
            {
                sf::VertexArray lines(sf::LinesStrip, 2);
                lines[0].position.x = e->getComponent<CTransform>().pos.x;
                lines[0].position.y = e->getComponent<CTransform>().pos.y;
                lines[0].color = sf::Color::Black;
                lines[1].position.x = m_player->getComponent<CTransform>().pos.x;
                lines[1].position.y = m_player->getComponent<CTransform>().pos.y;
                lines[1].color = sf::Color::Black;
                m_game->window().draw(lines);
                dot.setPosition(e->getComponent<CFollowPlayer>().home.x, e->getComponent<CFollowPlayer>().home.y);
                m_game->window().draw(dot);
            }
        }
    }
}
                 
std::shared_ptr<sf::Shader> Scene_Zelda::getShader(const std::string& shaderName, const std::string& shaderPath)
{
    if (m_shaderMap.find(shaderName) != m_shaderMap.end())
    {
        return m_shaderMap.at(shaderName);
    }

    std::shared_ptr<sf::Shader> shader = std::make_shared<sf::Shader>();
    if (!shader->loadFromFile(shaderPath, sf::Shader::Fragment))
    {
        std::cerr << "Could not load shader file: " << shaderName << std::endl;
    }
    else
    {
        std::cout << "Loaded Shader:    " << shaderName << std::endl;
    }

    m_shaderMap[shaderName] = shader;
    return shader;
}

void Scene_Zelda::updateSwordAnimation(std::shared_ptr<Entity> sword)
{
    std::shared_ptr<Entity> attachedTo = sword->getComponent<CAttachedTo>().attachedEntity;
    auto& aTrans = attachedTo->getComponent<CTransform>();
    if (!attachedTo->isActive())
    {
        sword->destroy();
    }

    if (aTrans.facing == Vec2(-1, 0))
    {
        auto& animation = m_game->assets().getAnimation("SwordRight");
        sword->addComponent<CAnimation>(animation, true);
        sword->addComponent<CBoundingBox>(animation.getSize());
        sword->addComponent<CTransform>(aTrans.pos + Vec2(-58, 0), Vec2(0, 0), Vec2(-1, 1), 0);
    }
    else if (aTrans.facing == Vec2(1, 0))
    {
        auto& animation = m_game->assets().getAnimation("SwordRight");
        sword->addComponent<CAnimation>(animation, true);
        sword->addComponent<CBoundingBox>(animation.getSize());
        sword->addComponent<CTransform>(aTrans.pos + Vec2(58, 0));
    }
    else if (aTrans.facing == Vec2(0, 1))
    {
        auto& animation = m_game->assets().getAnimation("SwordUp");
        sword->addComponent<CAnimation>(animation, true);
        sword->addComponent<CBoundingBox>(animation.getSize());
        sword->addComponent<CTransform>(aTrans.pos + Vec2(0, 58), Vec2(0, 0), Vec2(1, -1), 0);
    }
    else if (aTrans.facing == Vec2(0, -1))
    {
        auto& animation = m_game->assets().getAnimation("SwordUp");
        sword->addComponent<CAnimation>(animation, true);
        sword->addComponent<CBoundingBox>(animation.getSize());
        sword->addComponent<CTransform>(aTrans.pos + Vec2(0, -58));
    }
}

void Scene_Zelda::updateLaserAnimation(std::shared_ptr<Entity> laser)
{
    std::shared_ptr<Entity> attachedTo = laser->getComponent<CAttachedTo>().attachedEntity;
    if (!attachedTo->isActive())
    {
        laser->destroy();
    }

    // lasers begins from the front of the attached entity and stops when it hits an entity that blocks move, or hits the edge of the room
    auto& aTrans = attachedTo->getComponent<CTransform>();
    auto& aBoundingBox = attachedTo->getComponent<CBoundingBox>();
    bool facingLeftOrRight = aTrans.facing == Vec2(1, 0) || aTrans.facing == Vec2(-1, 0);
    float laserGridLength; // this will be used to scale the texture and bounding box size

    // set initial laser length as distance from starting position
    Vec2 roomTopLeftPos = Vec2(floor(aTrans.pos.x / 1280)*1280, floor(aTrans.pos.y / 768)*768);
    Vec2 roomBotRightPos = roomTopLeftPos + Vec2(1280, 768);
    Vec2 startingPos = Vec2(aTrans.pos.x, aTrans.pos.y);
    if (facingLeftOrRight)
    {
        float targetX = aTrans.facing.x == -1 ? roomTopLeftPos.x : roomBotRightPos.x;
        startingPos.x = aTrans.pos.x + aTrans.facing.x * aBoundingBox.halfSize.x;
        laserGridLength = abs(targetX- startingPos.x) / 64;
    }
    else
    {
        float targetY = aTrans.facing.y == -1 ? roomTopLeftPos.y : roomBotRightPos.y;
        startingPos.y = aTrans.pos.y + aTrans.facing.y * aBoundingBox.halfSize.y;
        laserGridLength = abs(targetY- startingPos.y) / 64;
    }

    // check if there are any entities that stop the laser (block move)
    for (auto& e : m_entityManager.getEntities())
    {
        if (e->id() == m_player->id() || e->id() == attachedTo->id() || e->id() == laser->id() || !e->hasComponent<CBoundingBox>() || !e->getComponent<CBoundingBox>().blockMove)
        {
            continue;
        }
        auto& eTrans = e->getComponent<CTransform>();
        if (Physics::EntityIntersect(startingPos, startingPos + aTrans.facing * laserGridLength * 64, e))
        {
            if (facingLeftOrRight && abs(eTrans.pos.x - aTrans.pos.x) / 64 - 1 < laserGridLength)
            {
                laserGridLength = abs(eTrans.pos.x - aTrans.pos.x) / 64 - 1;
            }
            else if (!facingLeftOrRight && abs(eTrans.pos.y - aTrans.pos.y) / 64 - 1 < laserGridLength)
            {
                laserGridLength = abs(eTrans.pos.y - aTrans.pos.y) / 64 - 1;
            }
        }
    }
    Vec2 pos = aTrans.pos + aTrans.facing * 64 * (0.5 + laserGridLength / 2);
    auto& animation = m_game->assets().getAnimation(facingLeftOrRight ? "LaserRight" : "LaserUp");
    laser->addComponent<CAnimation>(animation, true);
    laser->addComponent<CTransform>(pos, Vec2(0, 0), facingLeftOrRight ? Vec2(laserGridLength, 1) : Vec2(1, laserGridLength), 0);
    laser->addComponent<CBoundingBox>(facingLeftOrRight ? Vec2(animation.getSize().x * laserGridLength, animation.getSize().y) : Vec2(animation.getSize().x, animation.getSize().y * laserGridLength));
}

void Scene_Zelda::loadAIConfig(std::shared_ptr<Entity> entity, int rx, int ry, int tx, int ty, std::ifstream& fin)
{
    std::string aiBehaviorName;
    while (fin >> aiBehaviorName)
    {
        if (aiBehaviorName == "End")
        {
            break;
        }
        float s;
        if (aiBehaviorName == "Patrol")
        {
            int n, xi, yi;
            fin >> s >> n;
            std::vector<Vec2> positions;
            for (int i = 0; i < n; i++)
            {
                fin >> xi >> yi;
                positions.push_back(getPosition(rx, ry, xi, yi));
            }
            entity->addComponent<CPatrol>(positions, s);
        }
        else if (aiBehaviorName == "Follow")
        {
            fin >> s;
            entity->addComponent<CFollowPlayer>(getPosition(rx, ry, tx, ty), s);
        }
        else if (aiBehaviorName == "KeepDistance")
        {
            float r;
            fin >> s >> r;
            entity->addComponent<CKeepDistance>(s, r);
        }
        else if (aiBehaviorName == "Enraged")
        {
            int t, sm, dm;
            fin >> t >> sm >> dm;
            entity->addComponent<CEnraged>(s, t, sm, dm);
        }
    }
}

std::shared_ptr<WeaponConfig> Scene_Zelda::loadWeaponConfig(std::string weaponName, std::ifstream& fin)
{
    std::shared_ptr<WeaponConfig> config = std::make_shared<WeaponConfig>();
    config->name = weaponName;
    if (weaponName == "none")
    {
        return config;
    }
    fin >> config->damage >> config->cooldown >> config->lifespan;
    if (weaponName == "gun" || weaponName == "shotgun" || weaponName == "spreadgun")
    {
        fin >> config->bulletSpeed >> config->homingRadius;
    }
    return config;
}

float Scene_Zelda::getLightStrength(std::shared_ptr<Entity> entity)
{
    auto& eTrans = entity->getComponent<CTransform>();
    int eRx = floor(eTrans.pos.x / 1280);
    int eRy = floor(eTrans.pos.y / 768);

    float lightStrength = 0.05;

    if (darkRooms.find(std::make_pair(eRx, eRy)) != darkRooms.end())
    {
        // if the room is dark, light strength is based on its distance to the closest light source and the light source radius
        for (auto& e2 : m_entityManager.getEntities())
        {
            auto& e2Pos = e2->getComponent<CTransform>().pos;
            float dist = eTrans.pos.dist(e2Pos);
            if (e2->hasComponent<CLightSource>() && dist < e2->getComponent<CLightSource>().radius)
            {
                lightStrength = std::max(lightStrength, (e2->getComponent<CLightSource>().radius - dist) / e2->getComponent<CLightSource>().radius);
            }
        }
    }
    else
    {
        // if the room is not dark, light strength is 1
        lightStrength = 1;
    }

    return lightStrength;
}
                                                                          
// Copyright (C) David Churchill - All Rights Reserved
// COMP4300 - 2022-09 - Assignment 4
// Written by David Churchill (dave.churchill@gmail.com)
// Unauthorized copying of these files are strictly prohibited
// Distributed only for course work at Memorial University
// If you see this file online please contact email above
