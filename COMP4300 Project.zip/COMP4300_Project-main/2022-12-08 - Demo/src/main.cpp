///\/\/\\\\\//////\/\/\/\\\///\\\/\/\/\\\\\//////\/\/\/\\\///\\\
//
//  Assignment       COMP4300 - Assignment 4
//  Professor:       David Churchill
//  Year / Term:     2022-09
//  File Name:       main.cpp
// 
//  Student Name:    Yeong Shu Chun
//  Student User:    yschun
//  Student Email:   yschun@mun.ca
//  Student ID:      201623048
//  Group Member(s): [enter student name(s)]
//
///\/\/\\\\\//////\/\/\/\\\///\\\/\/\/\\\\\//////\/\/\/\\\///\\\

#include <SFML/Graphics.hpp>
                                                                          
#include "GameEngine.h"
                                                                          
int main()
{
    GameEngine g("assets.txt");
    g.run();
}

// Copyright (C) David Churchill - All Rights Reserved
// COMP4300 - 2022-09 - Assignment 4
// Written by David Churchill (dave.churchill@gmail.com)
// Unauthorized copying of these files are strictly prohibited
// Distributed only for course work at Memorial University
// If you see this file online please contact email above
